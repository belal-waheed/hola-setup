# Obelisk Theme for Microsoft Edge & Dark Reader

Bring the bespoke Obelisk design system (`#282a3a` / `#d9767d` / `#7fadd6`) to your browser.

---

## 1. Install Edge Theme (30 Seconds)

1. Open Microsoft Edge and go to `edge://extensions`.
2. Turn ON the **Developer mode** toggle in the left sidebar.
3. Click **Load unpacked** at the top.
4. Select this folder: `D:\dev\projects\custom\obelisk\edge-theme`
5. Edge will instantly apply the Obelisk Dark frame, toolbar, and address bar styling.

*(To switch to Light mode, rename `manifest-light.json` to `manifest.json` and click reload on the extension).*

---

## 2. Configure Dark Reader for Obelisk (All Webpages)

1. Click the **Dark Reader** extension icon in Edge.
2. Click **More / Settings** &rarr; **Manage Settings** &rarr; **Import settings**.
3. Choose `dark-reader-obelisk.json` located in this folder.
4. Every website (GitHub, documentation, Vercel, StackOverflow) will now render in authentic Obelisk Dark (`#282a3a` canvas with `#7fadd6` steel blue links and `#d9767d` accents).
