# Obelisk

**Obelisk** is a premium Obsidian theme built for developers, researchers, and writers. It offers an eye-comfortable muted jewel palette, seamless parity between Reading View and Live Preview, and full mobile optimization.

---

## Screenshots

### Dark Mode
![Dark Mode](dark.png)

### Light Mode
![Light Mode](light.png)

---

## Features

- **Reading & Live Preview Parity:** Identical styling across both modes for code blocks, tables, callouts, blockquotes, headings, links, hashtags, and checkboxes.
- **Smart Code Blocks:** Clean code containers where formatting backticks collapse out of sight when not actively editing.
- **Muted Jewel Colors:** Low-glare color palette with a 6-tier heading hierarchy (Red, Orange, Yellow, Cyan, Blue, Purple).
- **Animated Checkboxes:** Custom rounded checkboxes with task strikethrough.
- **Pill Hashtags & Centered Tables:** Rounded chip tags and auto-centered responsive tables.
- **Mobile Touch UX:** Expanded touch targets and smooth horizontal scrolling for wide content.

---

## Customization

Obelisk natively supports the **[Style Settings](https://github.com/mgmeyers/obsidian-style-settings)** plugin. You can adjust layout widths, font sizes, colors, corner radii, and table options directly from Obsidian settings.

1. Install **Style Settings** from **Settings > Community Plugins**.
2. Open **Settings > Style Settings > Obelisk** to customize your theme.

---

## Installation

### Manual Installation
1. Download `theme.css` and `manifest.json` from the latest release.
2. Place both files in your vault folder under `.obsidian/themes/Obelisk/`.
3. In Obsidian, go to **Settings > Appearance > Themes**, select **Obelisk**, and click **Use**.

---

## Recommended Fonts

- **Text & Interface:** [Inter](https://rsms.me/inter/)
- **Monospace & Code:** [JetBrains Mono](https://www.jetbrains.com/lp/mono/)

---

## Support & License

If you find Obelisk useful, please consider giving the repository a star on GitHub.

Released under the **MIT License**. Created by [Belal Waheed](https://github.com/BelalWaheed).
