#Requires AutoHotkey v2.0
#SingleInstance Force

; ============================================================
;  MOUSE DEBOUNCE FIX
;  Stops a worn-out mouse button from firing twice on one click.
; ============================================================

; ---- SETTINGS ----
; DebounceMs = how close together (in milliseconds) two clicks
; have to be before we treat the second one as a glitch.
;
; 40ms is a safe default — no human can click that fast on purpose,
; so real clicks (even fast ones) always pass through fine.
; If it's still double-clicking sometimes, raise this number (try 60 or 80).
; If it feels laggy or blocks real clicks, lower it (try 25 or 30).
DebounceMs := 40

; ---- INTERNAL STATE (leave this alone) ----
lastDown := Map("LButton", 0, "RButton", 0, "MButton", 0, "XButton1", 0, "XButton2", 0)
lastUp   := Map("LButton", 0, "RButton", 0, "MButton", 0, "XButton1", 0, "XButton2", 0)
isBlocked := Map("LButton", false, "RButton", false, "MButton", false, "XButton1", false, "XButton2", false)

HandleDown(btn) {
    global lastDown, lastUp, isBlocked, DebounceMs
    now := A_TickCount
    ; Block if this press comes too soon after either the last press
    ; OR the last release — a release-bounce (glitch right as you let go)
    ; would otherwise be mistaken for a brand-new real click.
    if (now - lastDown[btn] < DebounceMs || now - lastUp[btn] < DebounceMs) {
        isBlocked[btn] := true
        return
    }
    isBlocked[btn] := false
    lastDown[btn] := now
    Send "{" btn " down}"
}

HandleUp(btn) {
    global lastUp, isBlocked
    if (isBlocked[btn]) {
        ; this "up" belongs to the glitch click we blocked, swallow it too
        isBlocked[btn] := false
        return
    }
    lastUp[btn] := A_TickCount
    Send "{" btn " up}"
}

; Button 1 = Left click
*LButton::HandleDown("LButton")
*LButton up::HandleUp("LButton")

; Button 2 = Right click
*RButton::HandleDown("RButton")
*RButton up::HandleUp("RButton")

; Button 3 = Middle click (scroll wheel press)
*MButton::HandleDown("MButton")
*MButton up::HandleUp("MButton")

; Button 4 = Side button (usually "Back")
*XButton1::HandleDown("XButton1")
*XButton1 up::HandleUp("XButton1")

; Button 5 = Side button (usually "Forward")
*XButton2::HandleDown("XButton2")
*XButton2 up::HandleUp("XButton2")
