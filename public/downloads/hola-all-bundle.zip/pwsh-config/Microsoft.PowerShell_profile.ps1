# =============================================================================
# Microsoft.PowerShell_profile.ps1
# Agent-Safe, High-Performance & Zero-Latency Profile for PowerShell 7+
# =============================================================================

# =============================================================================
# 1. NON-INTERACTIVE / AGENT SESSION FAST GUARD
# =============================================================================
# If running in non-interactive mode, piped, redirected, or automated agent runners,
# exit immediately to ensure zero stdout pollution, sub-millisecond execution, and zero state tampering.
$isInteractive = $false
try {
    $isInteractive = (
        $Host.Name -in @('ConsoleHost', 'Visual Studio Code Host') -and
        -not [Console]::IsOutputRedirected -and
        -not [Console]::IsInputRedirected -and
        $Host.UI.SupportsVirtualTerminal
    )
} catch {
    $isInteractive = $false
}

if (-not $isInteractive) {
    return
}

# =============================================================================
# 2. OH-MY-POSH PROMPT INTEGRATION & CACHE MANAGEMENT
# =============================================================================
$ompConfig = 'V:\tools\shell\amro.omp.json'
$poshCache = "$env:USERPROFILE\.posh_init.ps1"

function Update-PoshCache {
    [CmdletBinding()]
    param()
    $targetConfig = 'V:\tools\shell\amro.omp.json'
    $targetCache  = "$env:USERPROFILE\.posh_init.ps1"

    if (-not (Get-Command oh-my-posh -ErrorAction SilentlyContinue)) {
        Write-Warning "oh-my-posh executable not found in PATH."
        return
    }

    try {
        $raw = if (Test-Path -LiteralPath $targetConfig) {
            oh-my-posh init pwsh --config $targetConfig --print
        } else {
            oh-my-posh init pwsh --print
        }

        if ($raw) {
            $content = ($raw -join [System.Environment]::NewLine)
            # Ensure POSH_SESSION_ID is dynamic per session and not locked to cache creation time
            $content = $content -replace '(?m)^\$env:POSH_SESSION_ID\s*=\s*"[^"]*";\s*', 'if (-not $env:POSH_SESSION_ID) { $env:POSH_SESSION_ID = [guid]::NewGuid().ToString() }; '
            [System.IO.File]::WriteAllText($targetCache, $content, [System.Text.UTF8Encoding]::new($false))
            Write-Host "Oh-My-Posh cache updated successfully at $targetCache" -ForegroundColor Green
        }
    } catch {
        Write-Error "Failed to update Oh-My-Posh cache: $_"
    }
}

if (-not (Test-Path -LiteralPath $poshCache -PathType Leaf)) {
    Update-PoshCache
}

if (Test-Path -LiteralPath $poshCache -PathType Leaf) {
    $env:POSH_SESSION_ID = [guid]::NewGuid().ToString()
    $env:POSH_CONFIG = $ompConfig
    . $poshCache
}

# =============================================================================
# 3. CLI UTILITIES & MODERN TOOLS (ZOXIDE, FZF, EZA, BAT, LAZYGIT, FASTFETCH)
# =============================================================================
# Zoxide smart directory jumper
if (Get-Command zoxide -ErrorAction SilentlyContinue) {
    Invoke-Expression (& zoxide init powershell | Out-String)
}

# PSFzf fuzzy finder keybindings (deferred to PowerShell.OnIdle in Section 4)

# Eza modern file listing
if (Get-Command eza -ErrorAction SilentlyContinue) {
    Remove-Alias -Name ls -Force -ErrorAction SilentlyContinue
    function ls { eza --icons --group-directories-first @args }
    function ll { eza -la --icons --group-directories-first @args }
    function la { eza -a --icons --group-directories-first @args }
    function lt { eza --tree --level=2 --icons @args }
}

# Bat syntax-highlighted cat
if (Get-Command bat -ErrorAction SilentlyContinue) {
    Remove-Alias -Name cat -Force -ErrorAction SilentlyContinue
    function cat { bat --paging=never @args }
}

# Lazygit & Fastfetch aliases
if (Get-Command lazygit -ErrorAction SilentlyContinue) {
    Set-Alias -Name lg -Value lazygit -Option AllScope -Force -ErrorAction SilentlyContinue
}

if (Get-Command fastfetch -ErrorAction SilentlyContinue) {
    Set-Alias -Name ff -Value fastfetch -Option AllScope -Force -ErrorAction SilentlyContinue
}

# =============================================================================
# 4. ZERO-LATENCY PSREADLINE & PSFZF (DEFERRED VIA ONIDLE)
# =============================================================================
$null = Register-EngineEvent -SourceIdentifier 'PowerShell.OnIdle' -MaxTriggerCount 1 -Action {
    try {
        Import-Module PSFzf -ErrorAction Stop
        Set-PsFzfOption -PSReadlineChordReverseHistory 'Ctrl+r' -PSReadlineChordProvider 'Ctrl+t' -ErrorAction SilentlyContinue
    } catch {}

    Set-PSReadLineOption -PredictionSource History -PredictionViewStyle ListView -EditMode Windows -ErrorAction SilentlyContinue
    Set-PSReadLineKeyHandler -Key UpArrow -Function HistorySearchBackward -ErrorAction SilentlyContinue
    Set-PSReadLineKeyHandler -Key DownArrow -Function HistorySearchForward -ErrorAction SilentlyContinue
}

# =============================================================================
# 5. WORKSPACE UTILITIES & SHORTCUTS (V:\ DEV DRIVE ALIGNED)
# =============================================================================
function ..       { Set-Location .. }
function ...      { Set-Location ..\.. }
function ....     { Set-Location ..\..\.. }
function root     { Set-Location "V:\" }
function dev      { Set-Location "V:\" }
function projects { Set-Location "V:\projects" }
function tools    { Set-Location "V:\tools" }
function ahk      { Set-Location "V:\tools\auto-hotkey" }
function hola     { Set-Location "D:\vault\hola" }
function su       { Set-Location "D:\learn\university\s7" }
function learn    { Set-Location "D:\learn" }
function media    { Set-Location "D:\media" }
function career   { Set-Location "D:\career" }
function dl       { Set-Location "D:\downloads" }

function media-dl {
    param([string]$Url)
    $runner = "V:\projects\media-inspector\run-media-dl.vbs"
    if (Test-Path -LiteralPath $runner) {
        if ($Url) {
            Start-Process "wscript.exe" -ArgumentList "`"$runner`" `"$Url`""
        } else {
            Start-Process "wscript.exe" -ArgumentList "`"$runner`""
        }
    } else {
        Write-Error "media-inspector not found at V:\projects\media-inspector"
    }
}

function reload {
    [CmdletBinding()]
    param(
        [Alias('f')]
        [switch]$Force
    )
    if ($Force) {
        Update-PoshCache
    }
    . $PROFILE
}

function profile { notepad $PROFILE }

# =============================================================================
# 6. FAST DIRECTORY NAVIGATION (QUICKNAV)
# =============================================================================
$profileDir = if ($PROFILE) { Split-Path -Parent $PROFILE } else { $PSScriptRoot }
$quickNavPath = Join-Path $profileDir 'Modules\QuickNav\QuickNav.psm1'
if (Test-Path -LiteralPath $quickNavPath) {
    Import-Module $quickNavPath -DisableNameChecking -ErrorAction SilentlyContinue
}


# =============================================================================
# 7. HIGH-VELOCITY VS CODE LAUNCHER & DYNAMIC PROFILES
# =============================================================================
$env:EDITOR = 'code'
$env:VISUAL = 'code'

function code-fast {
    [CmdletBinding()]
    param(
        [Parameter(ValueFromRemainingArguments = $true)]
        [string[]]$ArgumentList
    )
    $codeCmd = "D:\apps\Microsoft VS Code\bin\code.cmd"
    $codeGui = "D:\apps\Microsoft VS Code\Code.exe"

    if (-not $ArgumentList -or $ArgumentList.Count -eq 0) {
        & $codeGui
        return
    }

    # Route CLI operations, blocking wait calls, and diffs through official code.cmd
    $isCliOrWait = $false
    foreach ($arg in $ArgumentList) {
        if ($arg -in @('-w', '--wait', '-d', '--diff', '-m', '--merge', '--status', '-s', '--install-extension', '--uninstall-extension', '--list-extensions')) {
            $isCliOrWait = $true
            break
        }
    }

    if ($isCliOrWait -or $ArgumentList[0].StartsWith('-')) {
        & $codeCmd @ArgumentList
        return
    }

    # Case 1: Single file
    if (Test-Path -Path $firstArg -PathType Leaf) {
        $ext = [System.IO.Path]::GetExtension($firstArg).TrimStart('.').ToLower()
        $profile = switch ($ext) {
            { $_ -in 'py','ipynb','pyi','pyd' }                                               { 'Python' }
            { $_ -in 'tsx','jsx','ts','js','mjs','cjs','html','css','scss','sass','vue','svelte' } { 'React' }
            { $_ -in 'cs','csproj','sln','go','sql','rs','java' }                             { 'Backend' }
            { $_ -in 'cpp','c','cc','cxx','h','hpp' }                                         { 'cp' }
            default                                                                            { 'Instant' }
        }
        & "D:\apps\Microsoft VS Code\Code.exe" --profile $profile @ArgumentList
        return
    }

    # Case 2: Directory / Workspace
    if (Test-Path -Path $firstArg -PathType Container) {
        $profile = 'Instant'
        $resolved = Resolve-Path -Path $firstArg -ErrorAction SilentlyContinue
        if ($resolved) {
            $dir = $resolved.Path
            $files = Get-ChildItem -Path $dir -File -ErrorAction SilentlyContinue
            foreach ($f in $files) {
                $ext = $f.Extension.TrimStart('.').ToLower()
                $fName = $f.Name.ToLower()
                if ($ext -in 'csproj','sln','cs','fs','go','rs','sql' -or $fName -in 'go.mod','cargo.toml','pom.xml','build.gradle') {
                    $profile = 'Backend'; break
                }
                if ($fName -in 'package.json','tsconfig.json','vite.config.js','vite.config.ts','next.config.js','next.config.mjs' -or $ext -in 'tsx','jsx','vue','svelte') {
                    $profile = 'React'; break
                }
                if ($ext -in 'py','ipynb' -or $fName -in 'requirements.txt','pyproject.toml','pipfile','poetry.lock') {
                    $profile = 'Python'; break
                }
                if ($fName -in 'cmakelists.txt','makefile' -or $ext -in 'cpp','cc','cxx') {
                    $profile = 'cp'; break
                }
            }

            if ($profile -eq 'Instant') {
                $subDirs = Get-ChildItem -Path $dir -Directory -ErrorAction SilentlyContinue
                foreach ($sd in $subDirs) {
                    $sdName = $sd.Name.ToLower()
                    if ($sdName -in 'bin','obj') { $profile = 'Backend'; break }
                    if ($sdName -in 'node_modules') { $profile = 'React'; break }
                    if ($sdName -in '.venv','venv') { $profile = 'Python'; break }
                }
            }

            if ($profile -eq 'Instant') {
                $deepFiles = Get-ChildItem -Path $dir -Recurse -Depth 1 -File -ErrorAction SilentlyContinue | Where-Object { $_.DirectoryName -notmatch '(\\node_modules|\\.git|\\bin|\\obj|\\.venv)' }
                foreach ($df in $deepFiles) {
                    $ext = $df.Extension.TrimStart('.').ToLower()
                    $dfName = $df.Name.ToLower()
                    if ($ext -in 'csproj','sln','cs') { $profile = 'Backend'; break }
                    if ($dfName -in 'package.json' -or $ext -in 'tsx','jsx') { $profile = 'React'; break }
                    if ($ext -in 'py' -or $dfName -in 'requirements.txt') { $profile = 'Python'; break }
                    if ($dfName -in 'cmakelists.txt' -or $ext -in 'cpp') { $profile = 'cp'; break }
                }
            }
        }
        & "D:\apps\Microsoft VS Code\Code.exe" --profile $profile @ArgumentList
        return
    }

    & "D:\apps\Microsoft VS Code\Code.exe" @ArgumentList
}

Set-Alias -Name code -Value code-fast -Option AllScope -Force -ErrorAction SilentlyContinue
Set-Alias -Name v -Value code-fast -Option AllScope -Force -ErrorAction SilentlyContinue
Set-Alias -Name c -Value code-fast -Option AllScope -Force -ErrorAction SilentlyContinue
