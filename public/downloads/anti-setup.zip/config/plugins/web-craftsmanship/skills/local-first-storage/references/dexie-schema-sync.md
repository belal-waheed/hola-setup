# Dexie.js Schema, Reactive Queries, and Sync Engine Patterns

Reference implementations for Dexie.js strongly typed schemas, `useLiveQuery` hooks, offline mutation outbox, `BroadcastChannel` multi-tab sync, and quota management.

---

## 1. Strongly Typed Database & Schema Migrations

```typescript
// lib/db/schema.ts
import Dexie, { type Table } from 'dexie';

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  tags: string[];
  createdAt: number;
  updatedAt: number;
  isDeleted: boolean;
  version: number;
}

export interface SyncMutation {
  id: string;
  entityType: 'note' | 'setting';
  entityId: string;
  operation: 'CREATE' | 'UPDATE' | 'DELETE';
  payload: Record<string, unknown>;
  timestamp: number;
  retryCount: number;
  status: 'pending' | 'syncing' | 'failed';
}

export class AppDatabase extends Dexie {
  notes!: Table<NoteItem, string>;
  syncQueue!: Table<SyncMutation, string>;

  constructor() {
    super('AppDatabase');

    // Version 1: Initial schema
    this.version(1).stores({
      notes: 'id, createdAt, updatedAt, *tags',
      syncQueue: 'id, status, timestamp, entityType'
    });

    // Version 2: Added isDeleted soft-delete flag and compound index
    this.version(2).stores({
      notes: 'id, createdAt, updatedAt, isDeleted, [isDeleted+updatedAt], *tags',
      syncQueue: 'id, status, timestamp, entityType'
    }).upgrade(async (tx) => {
      await tx.table('notes').toCollection().modify((note: Partial<NoteItem>) => {
        note.isDeleted = false;
        note.version = 1;
      });
    });
  }
}

export const db = new AppDatabase();
```

---

## 2. Reactive React Queries with `useLiveQuery`

```tsx
// components/NoteList.tsx
import React from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../lib/db/schema';
import Dexie from 'dexie';

interface NoteListProps {
  filterTag?: string;
}

export function NoteList({ filterTag }: NoteListProps) {
  const notes = useLiveQuery(
    async () => {
      if (filterTag) {
        return await db.notes
          .where('tags')
          .equals(filterTag)
          .filter(note => !note.isDeleted)
          .reverse()
          .sortBy('updatedAt');
      }

      return await db.notes
        .where('[isDeleted+updatedAt]')
        .between([false, Dexie.minKey], [false, Dexie.maxKey])
        .reverse()
        .toArray();
    },
    [filterTag]
  );

  if (notes === undefined) {
    return <div className="animate-pulse p-4 text-muted-foreground">Loading notes...</div>;
  }

  if (notes.length === 0) {
    return <div className="p-4 text-muted-foreground">No notes found.</div>;
  }

  return (
    <ul className="divide-y divide-border">
      {notes.map(note => (
        <li key={note.id} className="p-3 hover:bg-muted/50 transition-colors">
          <h3 className="font-semibold">{note.title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2">{note.content}</p>
        </li>
      ))}
    </ul>
  );
}
```

---

## 3. Offline Mutation Outbox & Delta-Sync Engine

```typescript
// services/noteService.ts
import { db, type NoteItem, type SyncMutation } from '../lib/db/schema';

export async function createNote(title: string, content: string, tags: string[]): Promise<string> {
  const noteId = crypto.randomUUID();
  const timestamp = Date.now();

  const newNote: NoteItem = {
    id: noteId,
    title,
    content,
    tags,
    createdAt: timestamp,
    updatedAt: timestamp,
    isDeleted: false,
    version: 1,
  };

  const mutation: SyncMutation = {
    id: crypto.randomUUID(),
    entityType: 'note',
    entityId: noteId,
    operation: 'CREATE',
    payload: newNote,
    timestamp,
    retryCount: 0,
    status: 'pending',
  };

  await db.transaction('rw', [db.notes, db.syncQueue], async () => {
    await db.notes.add(newNote);
    await db.syncQueue.add(mutation);
  });

  return noteId;
}
```

---

## 4. Multi-Tab Synchronization via `BroadcastChannel`

```typescript
// lib/sync/tabChannel.ts
const SYNC_CHANNEL_NAME = 'app-storage-sync';
const channel = typeof BroadcastChannel !== 'undefined'
  ? new BroadcastChannel(SYNC_CHANNEL_NAME)
  : null;

export function broadcastSyncSignal(): void {
  channel?.postMessage({ type: 'DATA_CHANGED', timestamp: Date.now() });
}

export function subscribeToTabEvents(onSync: () => void): () => void {
  if (!channel) return () => {};

  const handler = (event: MessageEvent) => {
    if (event.data?.type === 'DATA_CHANGED') {
      onSync();
    }
  };

  channel.addEventListener('message', handler);
  return () => channel.removeEventListener('message', handler);
}
```

---

## 5. Storage Quota & Persistent Storage Management

```typescript
// lib/storage/quota.ts
export interface StorageStatus {
  usageBytes: number;
  quotaBytes: number;
  percentageUsed: number;
  isPersisted: boolean;
}

export async function checkStorageStatus(): Promise<StorageStatus> {
  let isPersisted = false;
  let usageBytes = 0;
  let quotaBytes = 0;

  if (navigator.storage && navigator.storage.persisted) {
    isPersisted = await navigator.storage.persisted();
  }

  if (navigator.storage && navigator.storage.estimate) {
    const estimate = await navigator.storage.estimate();
    usageBytes = estimate.usage ?? 0;
    quotaBytes = estimate.quota ?? 0;
  }

  const percentageUsed = quotaBytes > 0 ? (usageBytes / quotaBytes) * 100 : 0;

  return {
    usageBytes,
    quotaBytes,
    percentageUsed: Number(percentageUsed.toFixed(1)),
    isPersisted,
  };
}

export async function requestPersistentStorage(): Promise<boolean> {
  if (navigator.storage && navigator.storage.persist) {
    return await navigator.storage.persist();
  }
  return false;
}
```
