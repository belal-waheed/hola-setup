---
name: local-first-storage
description: Full-stack Local-First and client-side data architecture using Dexie.js (IndexedDB), reactive queries (useLiveQuery), schema versioning migrations, offline mutation queues, optimistic updates, and multi-tab synchronization. Use when building offline-first apps, local databases, or client-side caching.
---

# Local-First Storage & Offline-First Web Architecture

Production patterns for building resilient, zero-latency local-first web applications using **IndexedDB**, **Dexie.js**, reactive React hooks, background sync queues, and multi-tab coordination.

---

## When to Use This Skill

Trigger whenever designing or implementing:
- Client-side data storage using Dexie.js or native IndexedDB.
- Offline-capable PWAs that must function seamlessly without internet access.
- Schema migrations and upgrades across client devices.
- Reactive UI bindings via `useLiveQuery`.
- Mutation outbox queues, delta-sync, and conflict resolution (Last-Write-Wins, CRDT concepts).
- Storage quota estimation and persistent storage requests.
- Multi-tab synchronization using `BroadcastChannel`.

---

## 1. Local-First Core Principles

Adhere to the 7 ideals of local-first software:
1. **Zero Latency:** Reads and writes execute directly against local IndexedDB storage; UI never blocks on network roundtrips.
2. **Multi-device Availability:** Changes originate locally and synchronize asynchronously across all user nodes.
3. **Offline Sovereignty:** Full read and write capability persists during network partitions or offline states.
4. **Collaboration & Conflict Tolerance:** Concurrent modifications resolve cleanly without silent data loss.
5. **Longevity:** Data remains accessible even if central servers are discontinued.
6. **Privacy & Security First:** End-to-end encryption and client-side data boundaries.
7. **User Control:** Data export and import are always first-class citizens.

---

## 2. Architecture & Subsystem Guides

For complete pattern implementations and typed database schemas, consult:
- [Dexie Schema & Sync Patterns](references/dexie-schema-sync.md):
  - Strongly typed `AppDatabase` with versioned migration upgrades
  - Reactive React query integration with `useLiveQuery`
  - Offline mutation queue with transactional outbox writes
  - `BroadcastChannel` multi-tab synchronization
  - Storage quota estimation and persistence requests

---

## 3. Negative Constraints & Guardrails

- Never execute blocking network requests before writing to local IndexedDB; local persistence must complete first.
- Do not store unindexed non-searchable blobs inside primary entity tables; keep large binary assets in separate object stores or CacheStorage.
- Never alter Dexie store definitions without incrementing the database version number and writing an explicit `.upgrade()` migration.
- Avoid polling IndexedDB; use `useLiveQuery` or `BroadcastChannel` for reactive event notifications.

---

## 4. Verification & Testing

1. **Verify Database Initialization:**
   ```bash
   vitest run tests/db/schema.test.ts
   ```
2. **Offline Mutation Verification:**
   - Simulate browser offline mode (`navigator.onLine = false`).
   - Create and update records; verify they queue in `syncQueue` with `pending` status.
   - Restore online connectivity; assert queue draining and API dispatch.
