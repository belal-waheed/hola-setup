# Test Patterns & Anti-Pattern Catalog

Comparative reference of resilient behavioral tests versus fragile implementation-coupled tests.

---

## 1. Resilient Behavioral Tests

Test observable behaviors through public interfaces:

```typescript
// GOOD: Tests observable domain behavior
test("user can checkout with valid cart", async () => {
  const cart = createCart();
  cart.addItem(sampleProduct, 2);

  const result = await checkoutService.execute(cart, validPayment);

  expect(result.isSuccess).toBe(true);
  expect(result.value.status).toBe("confirmed");
});
```

### Characteristics
- Asserts on public contract and state transitions.
- Survives internal method refactorings.
- Expresses user/caller intent (*what*, not *how*).
- Uses one logical assertion per scenario.

---

## 2. Anti-Patterns to Eliminate

### A. Implementation Coupling
Coupling tests to private methods or invocation counts:

```typescript
// ANTI-PATTERN: Verifies internal call mechanics
test("checkout calls paymentService.process", async () => {
  const mockPayment = jest.spyOn(paymentService, 'process');
  await checkoutService.execute(cart, payment);
  expect(mockPayment).toHaveBeenCalledTimes(1); // Fragile
});
```

### B. Tautological Assertions
Recomputing expected results using the same logic as the production code:

```typescript
// ANTI-PATTERN: Recomputes implementation logic
test("calculateTotal sums line items", () => {
  const items = [{ price: 10 }, { price: 5 }];
  const expected = items.reduce((sum, i) => sum + i.price, 0); // Tautology
  expect(calculateTotal(items)).toBe(expected);
});

// GOOD: Independent known-good literal
test("calculateTotal sums line items", () => {
  expect(calculateTotal([{ price: 10 }, { price: 5 }])).toBe(15);
});
```

### C. Direct Database Side-Channel Verification
```typescript
// ANTI-PATTERN: Bypasses domain interface
test("createUser persists to database", async () => {
  await createUser({ name: "Alice" });
  const row = await db.query("SELECT * FROM users WHERE name = ?", ["Alice"]);
  expect(row).toBeDefined();
});

// GOOD: Verifies via domain retrieval interface
test("createUser makes user retrievable", async () => {
  const created = await createUser({ name: "Alice" });
  const fetched = await getUserById(created.id);
  expect(fetched?.name).toBe("Alice");
});
```
