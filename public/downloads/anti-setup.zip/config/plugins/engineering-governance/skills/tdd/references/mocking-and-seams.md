# System Seams & Boundary Mocking Reference

Guidelines for isolating dependencies and mocking strictly at system boundaries.

---

## 1. Where to Mock

Mock strictly at **system boundaries**:
- External third-party HTTP APIs (payment gateways, transactional email, SMS).
- External message queues / event brokers.
- Clocks, time providers, and non-deterministic randomness generators.
- Filesystems (when testing pure business logic).

### What Never to Mock
- Never mock internal domain services or application entities.
- Never mock internal collaborators under your direct control.
- Never mock the system under test (Arrange-Act-Assert invariant).

---

## 2. Designing for Mockability

### A. Dependency Injection at Boundaries
Pass external boundary adapters into domain handlers rather than instantiating them internally:

```typescript
// GOOD: Boundary client injected as interface
export async function processOrder(order: Order, paymentGateway: PaymentGateway): Promise<Result<TransactionId, PaymentError>> {
  return await paymentGateway.charge(order.total);
}

// ANTI-PATTERN: Hardcoded client instantiation
export async function processOrder(order: Order): Promise<Result<TransactionId, PaymentError>> {
  const gateway = new StripeGateway(process.env.STRIPE_KEY!);
  return await gateway.charge(order.total);
}
```

### B. Narrow Interface Segregation
Design narrow, specific interfaces per external domain capability instead of generic fetch wrappers:

```typescript
// GOOD: Narrow, explicit interface
export interface UserDirectoryService {
  getUserById(id: string): Promise<User | null>;
  listActiveUsers(): Promise<User[]>;
}

// ANTI-PATTERN: Generic monolithic client
export interface ApiClient {
  fetch(endpoint: string, options?: RequestInit): Promise<any>;
}
```
