---
name: tdd
description: Test-Driven Development (TDD) protocols, Red-Green-Refactor execution loops, seam isolation, and vertical tracer-bullet slicing. Use when practicing test-driven development, building features test-first, writing unit or integration tests, or refactoring code.
---

# Test-Driven Development (TDD) & Seam Isolation Protocol

Comprehensive engineering runbook for executing the strict **Red -> Green -> Refactor** development loop with high behavioral fidelity and zero implementation coupling.

---

## When to Use This Skill

Activate whenever:
- Designing new features test-first before writing production code.
- Fixing bugs by reproducing the failure scenario in a minimal failing test first.
- Identifying architectural seams and testing public interface contracts.
- Refactoring legacy logic while preserving observable behavior.

---

## 1. The Red -> Green -> Refactor Rules

Adhere strictly to the three laws of TDD:
1. **Red:** Write a minimal test specifying observable behavior at an interface seam. Run the test runner and verify that it fails for the expected reason.
2. **Green:** Write the simplest, cleanest implementation code that satisfies the failing assertion. Never anticipate speculative future requirements.
3. **Refactor:** Clean up duplication, enforce design patterns, and optimize readability only while all tests remain green.

---

## 2. Public Seam Isolation & Vertical Slicing

- **Test Public Interfaces Only:** Observe behavior through public inputs and outputs. Never write tests targeting private methods.
- **Vertical Tracer Bullet Slicing:** Avoid horizontal slicing (writing all test suites upfront before any implementation). Implement in narrow vertical slices: one test -> one minimal implementation -> repeat.
- **Seam Agreement:** Determine the public interface boundary before authoring tests.

---

## 3. Deep Pattern Reference Guides

For code samples, anti-pattern catalogs, and boundary mocking guidelines, consult:
- [Seams & Boundary Mocking Reference](references/mocking-and-seams.md):
  - Inversion of Control and boundary dependency injection
  - Segregating narrow mockable interfaces from generic fetchers
- [Test Patterns & Anti-Pattern Catalog](references/test-patterns.md):
  - Observable behavioral tests vs implementation-coupled tests
  - Eliminating tautological assertions and direct database side-channel checks

---

## 4. Verification & Runner Commands

Always execute the suite using the project's native runner:
```bash
# Node / TypeScript (Vitest or Jest)
vitest run --reporter=verbose

# C# (.NET / xUnit)
dotnet test --configuration Release --logger "console;verbosity=detailed"

# Python (pytest)
pytest -v -s
```

---

## 5. Negative Constraints & Guardrails

- Never mock the system under test or internal collaborators you control; mock strictly at external system boundaries (network, third-party APIs).
- Do not write tautological tests that recompute expected values using production code algorithms; always use independent, literal expected fixtures.
- Avoid asserting on call counts or execution ordering when state transitions or returned values can be verified directly.
