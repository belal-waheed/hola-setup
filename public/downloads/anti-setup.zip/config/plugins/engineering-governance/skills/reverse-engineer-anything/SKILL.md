---
name: reverse-engineer-anything
description: >-
  Reverse engineer native, managed, Electron/JavaScript, packaged, firmware, and browser targets with REA, and build agent environments (AgentEnv bundles) of web applications from a live instance or a capture, and of Linux desktop apps with a task from a request. Use shipped-artifact or requested runtime evidence to explain features, compare versions, decompile code, or guide a reconstruction. Skip REA for ordinary source-repository architecture analysis.
metadata:
  version: "62"
---

# REA (Reverse Engineer Anything)

Use REA when a claim depends on a shipped binary or package, decompilation, requested runtime evidence, or comparison with behavior not established by available source code. 

For ordinary analysis of a complete source repository, use normal repository tools and do not run REA readiness or provider commands.

---

## 1. Connection & Tool Setup

Installing this skill supplies instructions; it does not automatically register the REA MCP server or install native disassemblers.

### MCP Registration
To enable REA tools across sessions, configure the MCP server in `mcp_config.json`:

```json
{
  "mcpServers": {
    "rea": {
      "command": "npx",
      "args": ["-y", "rea-agents@latest", "mcp"]
    }
  }
}
```

### Direct CLI Fallback
When running without the MCP server or performing one-off artifact inspections:

```bash
# Analyze JavaScript tree or Electron ASAR archive
npx -y rea-agents@latest analyze-javascript-application /absolute/path/to/app --json

# Run diagnostics and check toolchain readiness
npx -y rea-agents@latest rea doctor
```

If tools are absent, a call is blocked, or a provider is unavailable, consult [connection and recovery](./references/connection-and-recovery.md).

---

## 2. Target Routing Dispatch

Choose the appropriate initial tool based on the supplied artifact:

- **Electron Apps & JavaScript Trees (.asar, Webpack, Vite)**: `analyze_javascript_application`. Consult [JavaScript Applications Guide](./references/javascript-applications.md).
- **.NET & Managed Code (.dll, .exe)**: `inspect_managed_artifact`. Consult [Native and Artifacts Guide](./references/native-and-artifacts.md).
- **Native Binaries (PE, ELF, Mach-O)**: `open_binary` followed by provider analysis (Ghidra/symbols).
- **Packages & Archives (ZIP, APK, MSIX, DMG, PyInstaller)**: `open_binary` with `inspect_artifact`.
- **Browser Targets & SPAs**: `list_browser_targets` or `capture_browser_scenario`. Consult [Runtime Observation Guide](./references/runtime-observation.md).
- **Web Network Captures (HAR, SAZ)**: `inspect_web_network_capture`.

For the exhaustive routing catalog covering Go, Rust, WebAssembly, Firmware, Apple bundles, and EVM bytecode, see the [Target Routing Matrix](./references/target-routing-matrix.md).

---

## 3. Investigation Methodology (The 7-Step Evidence Checklist)

For requests spanning multiple features or subsystems, execute this staged workflow strictly:

1. **Checklist & Evidence Framing**: Turn the user request into an explicit checklist of questions and the concrete evidence each requires. Resolve target identity and constraints before issuing analysis calls.
2. **Session & Artifact Inspection**: Inspect current REA session, artifact identity, hashes, and prior evidence. Reuse matching state; do not open duplicate sessions or repeat identical calls.
3. **Summary-First Exploration**: Start with `detail: "summary"` or top-level inventories. Follow each question from its entry point through relevant data/state changes to its result. Expand deeper only when returned evidence leaves a concrete gap.
4. **Configuration & Resource Correlation**: Inspect packaged resources (`package.json`, plists, manifests, fuses) alongside code. Use format-aware parsers; do not guess behavior from filenames or layout alone.
5. **Static vs. Runtime Grounding**: Corroborate conclusions with required evidence types. Use runtime observation only when static evidence is insufficient and host access is available.
6. **Task Decomposition**: Decompose complex questions into independent sub-investigations. Link findings to source files, decompiled functions, and entrypoints.
7. **Finding Ledger & Verification**: Maintain a concise finding ledger linking each conclusion to Evidence IDs, confidence level, search boundary, and remaining unknowns. Update investigation reports so subsequent passes can reuse results.

---

## 4. Evidence Integrity & Anti-AI Slop Invariants

When presenting reverse-engineering findings to the user:

- **Strict Categorization**: Every technical statement MUST distinguish:
  1. *Direct Static Observation* (e.g. symbol exists, string literal observed at offset, AST node present).
  2. *Inferred Candidate* (e.g. demangled name candidate, probable API route, reconstructed interface).
  3. *Unresolved Unknown* (e.g. dynamically computed dispatch, encrypted payload, missing symbol table).
- **No Hallucinated Execution**: Never state or imply that static symbols prove runtime execution unless corroborated by runtime captures.
- **Resource Cleanup**: Always close opened native sessions with `close_binary` when the analysis engine is no longer needed. Conclude investigations with `reset_investigation`.

---

## 5. Reference Documentation Index

Consult the specialized sub-guides for deep procedures:
- [JavaScript & Electron Applications](./references/javascript-applications.md)
- [Native Binaries & Managed Artifacts](./references/native-and-artifacts.md)
- [Android Applications & APKs](./references/android-applications.md)
- [Runtime Observation & Browser Capture](./references/runtime-observation.md)
- [Evidence Workflows & Verification](./references/evidence-workflows.md)
- [Agent Environments (AgentEnv Bundles)](./references/environments.md)
- [Desktop App Build Environments](./references/desktop-build.md)
- [Connection, Diagnostics & Recovery](./references/connection-and-recovery.md)
- [Complete Target Routing Matrix](./references/target-routing-matrix.md)
