# REA Target Routing Matrix & Tool Catalog

Choose the first tool from the target the user supplied. Use `open_binary` for active-target native or archive workflows; target-free tools take their own explicit path or endpoint and do not need it.

---

## 1. Web, JavaScript & Desktop Targets

- **ASAR or extracted JavaScript/Electron tree**:
  `analyze_javascript_application`.
- **User-owned browser page already open**:
  `list_browser_targets`.
- **Browser action the agent must perform (click, type, navigate)**:
  `capture_browser_scenario` with declared actions. See [runtime observation](./runtime-observation.md).
- **User-owned Electron runtime already open**:
  `list_electron_targets`. Before an electron-main Inspector attempt, check packaged fuses with `inspect_electron_fuses`; disabled `EnableNodeCliInspectArguments` means the app ignores `--inspect`.
- **Passive traffic capture of a SPA**:
  Scope to page origin and API origins via `allowed_origins`.
- **Retained HAR/SAZ/mitmproxy/qlog capture**:
  `inspect_web_network_capture` with format `har` or `saz`.

---

## 2. Managed Code & Package Containers

- **Managed PE/CLI assembly (.NET / C#)**:
  `inspect_managed_artifact`. Analyzes types, members, and metadata tables without requiring full disassembler run.
- **Archive/package member inventory (ZIP/APK/IPA/MSIX/AppX, DMG, PyInstaller)**:
  `open_binary` with local path; use `inspect_artifact` for graph and findings.
- **Bun standalone executable**:
  `open_binary`, then `inspect_artifact`. Bun module graph is the application layer.
- **Deno standalone executable**:
  `open_binary`, then `inspect_artifact`. Embedded VFS is the application layer.
- **Android APK code, classes, methods**:
  `inspect_android_package`, then focused Android tools. See [android applications](./android-applications.md).
- **Android APK signing**:
  `inspect_apk_signature`. Reports schemes (v1, v2, v3, v3.1), SHA-256 fingerprints, and key-rotation lineage.

---

## 3. Native Binaries & System Images

- **Native PE/ELF/Mach-O Binaries**:
  Native analysis via Ghidra provider with `open_binary`.
- **PE Authenticode certificate table**:
  `inspect_pe_certificates` (extracts WIN_CERTIFICATE, PKCS#7 signer identity).
- **PE import & delay-load tables**:
  `inspect_pe_imports` (extracts DLLs, functions, ILT/IAT RVAs, pefile import hash).
- **PE TLS callbacks and load configuration**:
  `inspect_pe_load_config` (security cookies, SafeSEH, CFG, XFG).
- **ELF, PE, and Mach-O hardening**:
  `inspect_binary_hardening` (stack-protector, fortify, ASLR/PIE, DEP/NX, code signatures).
- **Embedded Go binary metadata**:
  `inspect_go_binary` (compiler, module paths, static string literals without Go toolchain).
- **Embedded Rust dependency metadata**:
  `inspect_rust_binary` (auditable cargo dependencies, `.dep-v0` section).
- **WebAssembly (.wasm)**:
  `inspect_wasm_artifact` (requires WABT 1.0.42; decodes WAT and imports/exports).
- **Firmware image**:
  `inspect_firmware_regions` and `extract_firmware` (uses Binwalk/Unblob).
- **ESP32-family bootloader image**:
  `inspect_artifact` (`0xE9` magic).
- **Apple resources**:
  `open_bundle_resources` (plists, asset catalogs, keyed archives).
- **Apple crash reports**:
  `inspect_apple_ips` (bug_type 309 crash dumps).
- **Linux kernel module**:
  `inspect_kernel_module` (.modinfo, __versions CRC hex, PKCS#7 trailer).
- **Windows Shell Link shortcuts**:
  `inspect_windows_shortcut` (.lnk header flags, IDList, LinkInfo, ExtraData).
- **EVM bytecode**:
  `inspect_evm_interface` (raw or hex selectors and candidate dispatch interface).
- **Unity IL2CPP metadata**:
  `inspect_il2cpp_metadata` (global-metadata.dat sections, images, types, string literals).
