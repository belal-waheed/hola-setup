import fs from 'node:fs';

const DESTRUCTIVE_PATTERNS = [
  /git\s+reset\s+--hard/i,
  /git\s+push\s+.*(--force|-f\b)/i,
  /git\s+clean\s+(-[a-zA-Z]*f|--force)/i,
  /(rmdir|del)\s+.*(\/s|\/q).*[cC]:\\?/i,
  /rm\s+-rf\s+(\/|[a-zA-Z]:\\?$)/i,
];

function main() {
  try {
    const input = fs.readFileSync(0, 'utf-8');
    if (!input || !input.trim()) {
      process.stdout.write(JSON.stringify({ decision: 'allow' }));
      return;
    }

    const payload = JSON.parse(input);
    const toolCall = payload.toolCall;

    if (!toolCall || toolCall.name !== 'run_command' || !toolCall.args) {
      process.stdout.write(JSON.stringify({ decision: 'allow' }));
      return;
    }

    let commandLine = toolCall.args.CommandLine || '';

    // 1. Guard against destructive commands
    for (const pattern of DESTRUCTIVE_PATTERNS) {
      if (pattern.test(commandLine)) {
        process.stdout.write(
          JSON.stringify({
            decision: 'deny',
            reason: 'Destructive command blocked by Antigravity shell-guard hook.',
          })
        );
        return;
      }
    }

    // 2. Enforce -NoProfile on PowerShell commands
    const isPwsh = /^\s*(pwsh|powershell)(\.exe)?\b/i.test(commandLine);
    const hasNoProfile = /\s+(-noprofile|-nop)\b/i.test(commandLine);

    if (isPwsh && !hasNoProfile) {
      const modifiedCommand = commandLine.replace(
        /^\s*(pwsh|powershell)(\.exe)?\b/i,
        (match) => `${match} -NoProfile`
      );

      process.stdout.write(
        JSON.stringify({
          decision: 'allow',
          overwrite: {
            CommandLine: modifiedCommand,
          },
        })
      );
      return;
    }

    process.stdout.write(JSON.stringify({ decision: 'allow' }));
  } catch (err) {
    process.stdout.write(JSON.stringify({ decision: 'allow' }));
  }
}

main();
