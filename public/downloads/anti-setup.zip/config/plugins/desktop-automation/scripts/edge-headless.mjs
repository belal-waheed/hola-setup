#!/usr/bin/env node
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';

function printHelp() {
  console.log(`
Usage: node edge-headless.mjs --url <URL> [options]

Options:
  --url <URL>              Target URL to navigate to (required)
  --screenshot <file>      Path to save PNG screenshot
  --dump-dom               Dump DOM HTML to stdout
  --window-size <W,H>      Viewport size (default: 1280,800)
  --timeout <ms>           Execution timeout in ms (default: 15000)
  --help                   Display this help message
`);
}

function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    url: null,
    screenshot: null,
    dumpDom: false,
    windowSize: '1280,800',
    timeout: 15000,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--url' && args[i + 1]) {
      options.url = args[++i];
    } else if (arg === '--screenshot' && args[i + 1]) {
      options.screenshot = args[++i];
    } else if (arg === '--dump-dom') {
      options.dumpDom = true;
    } else if (arg === '--window-size' && args[i + 1]) {
      options.windowSize = args[++i];
    } else if (arg === '--timeout' && args[i + 1]) {
      options.timeout = parseInt(args[++i], 10);
    } else if (arg === '--help' || arg === '-h') {
      printHelp();
      process.exit(0);
    }
  }

  return options;
}

async function run() {
  const options = parseArgs();

  if (!options.url) {
    console.error('Error: --url is required.');
    printHelp();
    process.exit(1);
  }

  if (!fs.existsSync(EDGE_PATH)) {
    console.error(`Error: Microsoft Edge executable not found at: ${EDGE_PATH}`);
    process.exit(1);
  }

  const edgeArgs = [
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    '--disable-dev-shm-usage',
    `--window-size=${options.windowSize}`,
  ];

  if (options.screenshot) {
    const resolvedPath = path.resolve(options.screenshot);
    edgeArgs.push(`--screenshot=${resolvedPath}`);
  }

  if (options.dumpDom) {
    edgeArgs.push('--dump-dom');
  }

  edgeArgs.push(options.url);

  const proc = spawn(EDGE_PATH, edgeArgs, {
    stdio: ['ignore', options.dumpDom ? 'inherit' : 'pipe', 'pipe'],
  });

  let stderr = '';
  if (proc.stderr) {
    proc.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
  }

  const timeoutId = setTimeout(() => {
    proc.kill();
    console.error(`Error: Edge headless command timed out after ${options.timeout}ms`);
    process.exit(1);
  }, options.timeout);

  proc.on('close', (code) => {
    clearTimeout(timeoutId);
    if (code !== 0) {
      console.error(`Edge exited with code ${code}. Stderr: ${stderr}`);
      process.exit(code || 1);
    }

    if (options.screenshot) {
      const resolvedPath = path.resolve(options.screenshot);
      if (fs.existsSync(resolvedPath)) {
        const stats = fs.statSync(resolvedPath);
        console.log(`[PASS] Screenshot saved: ${resolvedPath} (${stats.size} bytes)`);
      } else {
        console.error(`[FAIL] Screenshot file was not created at ${resolvedPath}`);
        process.exit(1);
      }
    }
  });
}

run();
