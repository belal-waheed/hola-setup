---
name: tauri-v2-rust
description: Official Tauri v2 and Rust desktop application architecture covering IPC commands, thread-safe state management, capabilities security model, system tray, window lifecycles, and background daemons. Use when building, debugging, or reviewing Tauri v2 desktop applications.
---

# Tauri v2 & Rust Desktop Application Architecture

Comprehensive architecture and implementation standards for **Tauri v2** desktop applications using Rust, native system integration, the v2 permissions/capabilities security model, and frontend IPC bindings.

---

## When to Use This Skill

Trigger whenever building, refactoring, or securing Tauri desktop applications:
- Writing Rust IPC commands with `#[tauri::command]` and thread-safe managed state.
- Configuring Tauri v2 security boundaries, permissions, and `src-tauri/capabilities/*.json`.
- Implementing system tray icons, menus, and window visibility toggles (hide-on-minimize / hide-on-close).
- Managing multi-window lifecycles using `WebviewWindowBuilder`.
- Setting up background daemons, autostart on system boot, or single-instance guards.

---

## 1. Tauri v2 vs v1 Architecture Highlights

| Feature | Tauri v1 | Tauri v2 |
|---|---|---|
| **Security Model** | Monolithic `allowlist` in `tauri.conf.json` | Modular **Capabilities** and **Permissions** (`src-tauri/capabilities/`) |
| **System Tray** | `SystemTray` & `SystemTrayEvent` | `tauri::tray::TrayIconBuilder` & `MenuBuilder` |
| **Core Imports** | `@tauri-apps/api/tauri` (`invoke`) | `@tauri-apps/api/core` (`invoke`) |
| **Mobile Support** | Experimental / Separate | First-class unified desktop & mobile runtime |
| **Plugins** | In-crate features | Standalone modular crates (`tauri-plugin-*`) |

---

## 2. Tauri v2 Security & Capabilities Model

In Tauri v2, permissions are declared per capability file in `src-tauri/capabilities/`.

### Default Capability Configuration
```json
// src-tauri/capabilities/default.json
{
  "$schema": "../gen/schemas/desktop-schema.json",
  "identifier": "default-capability",
  "description": "Permissions for main application window",
  "windows": ["main"],
  "permissions": [
    "core:default",
    "shell:allow-open",
    "autostart:default"
  ]
}
```

### Hardening Rules
1. **Principle of Least Privilege:** Never grant `*:*` or wildcard permissions.
2. **Explicit Window Scoping:** Restrict permissions to specific window labels (`windows: ["main"]`).
3. **URL Validation in Shell:** When using `shell:allow-open`, configure strict regex filters to prevent arbitrary command execution or protocol hijacking.

---

## 3. Implementation Patterns Reference

For complete, compilable implementations of IPC handlers, system tray setup, and window builders, consult:
- [Tauri v2 IPC & Tray Patterns](references/tauri-ipc-patterns.md):
  - Rust IPC command with mutex-managed state
  - `lib.rs` builder with plugins and invoke handler registration
  - TypeScript typed invoke client
  - System tray builder with left-click toggle and custom menu
  - Multi-window spawn and focus manager

---

## 4. Verification & Testing

Validate Tauri v2 desktop application compilation, capabilities, and unit tests:
1. **Lint and Static Analysis:**
   ```bash
   cargo clippy --all-targets -- -D warnings
   ```
2. **Execute Rust Test Suite:**
   ```bash
   cargo test --workspace
   ```
3. **Verify Tauri Dev Build & Window Lifecycle:**
   ```bash
   pnpm tauri dev
   ```
4. **Audit Capabilities & Permissions:**
   Ensure `src-tauri/capabilities/main.json` explicitly grants only the required plugin permissions (e.g., `core:default`, `fs:read-text-file`, `tray:default`).

---

## 5. Negative Constraints & Guardrails

- Never invoke shell commands directly from the frontend without strict capability filtering.
- Do not block the Tauri main thread with long-running synchronous Rust code; always use `async` commands or `tauri::async_runtime::spawn`.
- Avoid storing plaintext credentials in application state; integrate OS keychains via `tauri-plugin-stronghold` or keyring libraries.
