# Tauri v2 IPC, System Tray, and Multi-Window Patterns

Reference implementations for Rust IPC commands, application bootstrapping, TypeScript bindings, and background tray lifecycle in Tauri v2.

---

## 1. Rust IPC Commands with Typed Managed State

```rust
// src-tauri/src/commands.rs
use std::sync::Mutex;
use serde::{Deserialize, Serialize};
use tauri::State;

#[derive(Default)]
pub struct AppState {
    pub counter: Mutex<i32>,
}

#[derive(Serialize, Deserialize)]
pub struct CommandPayload {
    pub message: String,
    pub delta: i32,
}

#[derive(Serialize)]
pub struct CommandResponse {
    pub success: bool,
    pub current_value: i32,
}

#[tauri::command]
pub async fn increment_counter(
    payload: CommandPayload,
    state: State<'_, AppState>,
) -> Result<CommandResponse, String> {
    let mut counter = state
        .counter
        .lock()
        .map_err(|e| format!("Failed to acquire lock: {}", e))?;

    *counter += payload.delta;

    Ok(CommandResponse {
        success: true,
        current_value: *counter,
    })
}
```

---

## 2. Application Bootstrap (`lib.rs`)

```rust
// src-tauri/src/lib.rs
mod commands;

use commands::{increment_counter, AppState};

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_autostart::init(
            tauri_plugin_autostart::MacosLauncher::LaunchAgent,
            Some(vec!["--minimized"]),
        ))
        .manage(AppState::default())
        .invoke_handler(tauri::generate_handler![
            increment_counter
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

---

## 3. TypeScript IPC Invocation

```typescript
// src/lib/api.ts
import { invoke } from '@tauri-apps/api/core';

export interface CommandPayload {
  message: string;
  delta: number;
}

export interface CommandResponse {
  success: boolean;
  current_value: number;
}

export async function executeIncrement(delta: number): Promise<CommandResponse> {
  try {
    return await invoke<CommandResponse>('increment_counter', {
      payload: {
        message: 'Increment requested',
        delta,
      },
    });
  } catch (err) {
    console.error('IPC command failed:', err);
    throw new Error(typeof err === 'string' ? err : 'Unknown IPC error');
  }
}
```

---

## 4. System Tray & Background Daemon Setup

```rust
// src-tauri/src/tray.rs
use tauri::{
    menu::{MenuBuilder, MenuItemBuilder},
    tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent},
    AppHandle, Manager,
};

pub fn create_tray(app: &AppHandle) -> Result<(), Box<dyn std::error::Error>> {
    let show_item = MenuItemBuilder::with_id("show", "Show Application").build(app)?;
    let quit_item = MenuItemBuilder::with_id("quit", "Quit").build(app)?;

    let menu = MenuBuilder::new(app)
        .items(&[&show_item, &quit_item])
        .build()?;

    let _tray = TrayIconBuilder::new()
        .icon(app.default_window_icon().unwrap().clone())
        .menu(&menu)
        .menu_on_left_click(false)
        .on_menu_event(|app, event| match event.id.as_ref() {
            "show" => {
                if let Some(window) = app.get_webview_window("main") {
                    let _ = window.show();
                    let _ = window.set_focus();
                }
            }
            "quit" => {
                app.exit(0);
            }
            _ => {}
        })
        .on_tray_icon_event(|tray, event| {
            if let TrayIconEvent::Click {
                button: MouseButton::Left,
                button_state: MouseButtonState::Up,
                ..
            } = event
            {
                let app = tray.app_handle();
                if let Some(window) = app.get_webview_window("main") {
                    let is_visible = window.is_visible().unwrap_or(false);
                    if is_visible {
                        let _ = window.hide();
                    } else {
                        let _ = window.show();
                        let _ = window.set_focus();
                    }
                }
            }
        })
        .build(app)?;

    Ok(())
}
```

---

## 5. Multi-Window Lifecycles

```rust
// src-tauri/src/windows.rs
use tauri::{AppHandle, WebviewUrl, WebviewWindowBuilder};

pub fn open_settings_window(app: &AppHandle) -> Result<(), tauri::Error> {
    if let Some(existing) = app.get_webview_window("settings") {
        existing.show()?;
        existing.set_focus()?;
        return Ok(());
    }

    WebviewWindowBuilder::new(app, "settings", WebviewUrl::App("/settings".into()))
        .title("Application Settings")
        .inner_size(600.0, 480.0)
        .resizable(false)
        .center()
        .build()?;

    Ok(())
}
```
