---
name: domain-modeling
description: Domain-Driven Design (DDD) modeling protocols, ubiquitous language enforcement, aggregate root boundaries, entities vs value objects, and living ADR documentation. Use when designing domain models, defining ubiquitous vocabulary, establishing bounded contexts, or recording architectural decisions.
---

# Domain Modeling & Ubiquitous Language Protocol

Comprehensive engineering runbook for establishing, refining, and enforcing strict domain models, bounded contexts, and aggregate boundaries according to Domain-Driven Design (DDD) principles.

---

## When to Use This Skill

Activate whenever:
- Designing new business domains, aggregates, entities, and value objects.
- Establishing or reconciling ubiquitous terminology in `CONTEXT.md`.
- Formalizing structural architectural choices in Architecture Decision Records (`docs/adr/`).
- Resolving conceptual ambiguities between database tables and business invariants.

---

## 1. Core Operating Principles

1. **Ubiquitous Language Enforcement:** Enforce identical naming across domain conversations, specifications, types, and persistence schemas. Reject synonyms and ambiguous abstractions.
2. **Entity vs. Value Object Distinction:**
   - **Entity:** Has unique, enduring identity across time (`id: OrderId`). Mutable only through explicit aggregate methods.
   - **Value Object:** Immutable, defined solely by its attributes (`Money`, `Address`, `DateRange`). Equality is structural.
3. **Aggregate Root Boundaries:** Access and modify child entities strictly through the Aggregate Root. Aggregates enforce their own invariants internally before persisting state.
4. **Result Pattern for Invariants:** Never throw unhandled exceptions for expected domain rule rejections. Methods return `Result<T, DomainError>`.

---

## 2. Directory & Documentation Conventions

- **Single Context Repository:**
  - `CONTEXT.md` at project root.
  - `docs/adr/NNNN-decision-title.md` for living architecture decisions.
- **Multi-Context Monorepo:**
  - `CONTEXT-MAP.md` at root linking to bounded contexts: `src/<context>/CONTEXT.md`.
- Consult [Context Specification & ADR Reference](references/context-and-adr-specs.md) for full templates.

---

## 3. Verification & Testing

Validate domain invariants and aggregate state machines:
```bash
# Verify domain unit test suite (Pure AAA testing with zero external mocks)
vitest run tests/domain/

# In C# .NET
dotnet test --filter "Category=Domain"
```

---

## 4. Negative Constraints & Guardrails

- Never leak database or ORM annotations (e.g. EF Core `[Key]`, Mongoose schemas, SQL column names) into pure domain entities.
- Do not use primitive types for rich domain concepts (eliminate Primitive Obsession: use `EmailAddress` or `CurrencyAmount` instead of raw `string` or `number`).
- Avoid anemic domain models where entities are dumb property bags with public setters and all business logic lives in external procedural services.
