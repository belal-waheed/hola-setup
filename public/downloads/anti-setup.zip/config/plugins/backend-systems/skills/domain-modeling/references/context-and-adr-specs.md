# Context Specification & ADR Format Reference

Reference standards for structuring `CONTEXT.md` glossaries and Architecture Decision Records (ADRs).

---

## 1. Living Domain Glossary (`CONTEXT.md`)

```markdown
# [Project Name] Domain Context & Glossary

Living dictionary of ubiquitous domain terminology, aggregate boundaries, and business invariants.

---

## 1. Ubiquitous Domain Terminology

| Term | Canonical Definition | Disallowed / Deprecated Synonyms | Boundary Context |
| :--- | :--- | :--- | :--- |
| `Customer` | Verified business or individual with an active billing agreement. | Do not call `User` or `Account`. | Identity & Billing |
| `Order` | An immutable transaction manifest containing line items and payment terms. | Do not call `Cart` or `Invoice`. | Ordering Core |

---

## 2. Invariants & Business Rules

- **INV-01 (Order Immutability):** An Order once placed (`status: Submitted`) cannot alter its line items; amendments require a cancellation or compensatory order.
- **INV-02 (Price Precision):** All monetary values are represented as integer cents or high-precision decimals (`Money` value object).
```

---

## 2. Architecture Decision Record Format (`docs/adr/NNNN-title.md`)

```markdown
# ADR-[NNNN]: [Short Architecture Decision Title]

**Status:** Proposed | Accepted | Superseded | Deprecated  
**Date:** YYYY-MM-DD  
**Deciders:** [Engineering Lead / Contributors]  
**Consulted:** [Domain Expert / Architect]  

---

## 1. Context & Problem Statement
What technical challenge or business constraint necessitates this architectural decision?

## 2. Decision Drivers
- Latency and throughput requirements
- Developer cognitive load and onboarding speed
- Operational overhead and maintenance cost

## 3. Considered Options
- **Option 1:** [Description]
- **Option 2:** [Description]

## 4. Decision Outcome
Chosen **Option 1** because [concrete rationale].

### Positive Consequences
- [Measurable improvement]

### Negative Consequences & Trade-offs
- [Accepted cost or limitation]
```
