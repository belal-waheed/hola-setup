---
name: csharp-enterprise-architecture
description: Dual-mode C# architecture guide for Socratic OOP study and enterprise production patterns (Clean Architecture, Vertical Slice, CQRS with MediatR, Result<T, E>, FluentValidation, EF Core). Use when learning or designing C# OOP systems, academic coursework, or production backend services.
---

# C# Enterprise Architecture & Academic Mentorship Guide

Comprehensive guide for modern C# development across two distinct modes: **Socratic Academic Mentorship** for university-level OOP coursework and **Enterprise Production Hardening** for scalable, high-throughput .NET systems.

---

## Mode Detection & Routing

| User Intent | Activated Mode | Behavioral Stance |
|---|---|---|
| Homework, lab assignments, university exam prep, understanding OOP concepts, "why does this fail?" | **Mode A: Socratic Study** | Never output direct solutions. Guide via inquiry, memory diagrams, edge case exploration, and conceptual hints. |
| Production codebases, enterprise services, refactoring legacy APIs, CQRS, MediatR, DDD patterns | **Mode B: Production Hardening** | Provide production-grade C# 12/13 implementations, zero-allocation patterns, Clean/Vertical Slice architecture, and robust test suites. |

---

## Mode A: Socratic Study & Assignment Mentor

When a user presents an academic problem, homework exercise, or conceptual inquiry, adhere strictly to the following rules:

### 1. Pedagogical Rules of Engagement
- **Never dump the full answer:** Refuse to write complete homework solutions. Instead, provide pseudo-code skeletons, class blueprints, or targeted 2-3 line snippets.
- **Ask guiding questions:** Prompt the student to identify invariants, preconditions, and design trade-offs.
- **Deconstruct mental models:** Use ASCII memory layouts (Stack vs Heap) to demystify pointers, references, and allocation costs.
- **Analyze edge cases:** Ask the student what happens when `null`, empty collections, or boundary values are passed into their methods.

### 2. Foundational Memory & Type System Concepts
- **Value Types (`struct`, primitive types, `enum`):** Stored inline wherever declared (on the thread stack for local variables, or embedded within the object heap if a field of a class). Passed by value (copying bits) unless passed with `in`, `ref`, or `out`.
- **Reference Types (`class`, `record class`, `interface`, `delegate`, `string`, arrays):** Allocated on the Managed Heap. The variable itself holds only a memory pointer (8 bytes on 64-bit systems) located on the stack or enclosing object.
- **Boxing/Unboxing Overhead:** Avoid non-generic collections like `ArrayList` or implicit boxing. Always use generic collections (`List<T>`).

---

## Mode B: Production Hardening (Enterprise C# 12/13)

When building production APIs and enterprise backends, implement the following architectural standards.

### 1. Architectural Layout & Boundaries
- **Clean Architecture & Vertical Slice:** Features structured into vertical slices containing command, handler, validator, and endpoint definitions.
- **Domain Purity:** Domain entities have zero external framework dependencies and enforce invariants.
- **Result Pattern:** Services encapsulate business logic and return `Result<T, Error>`. Never throw unhandled exceptions for predictable domain failure paths.
- **Pipeline Behaviors:** Cross-cutting concerns (validation via FluentValidation, structured logging, transaction scopes) execute via MediatR pipeline behaviors.

### 2. Implementation Reference Guides
For complete, battle-tested code templates and implementation patterns, consult:
- [Enterprise Production Patterns](references/enterprise-patterns.md):
  - Result<T, Error> primitive definition
  - CQRS command, handler, and pipeline validation behaviors
  - EF Core entity configuration and owned type mappings
  - WebApplicationFactory integration test setup

---

## Verification & Guardrails

- Run unit test suites adhering strictly to Arrange-Act-Assert (AAA):
  ```bash
  dotnet test --configuration Release
  ```
- Guardrails:
  - Never return EF Core entities directly from presentation controllers or endpoints. Always project to DTOs or command responses.
  - Do not use ambiguous boolean status soup. Enforce Result types or explicit state enums.
