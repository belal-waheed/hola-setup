<!-- Unified in ~/.gemini/GEMINI.md -->
