---
name: browser-automation
description: Workflows and CLI patterns for headless Google Chrome browser automation, UI layout verification, DOM scraping, visual regression screenshots, and Playwright/Puppeteer configurations using the installed Google Chrome engine.
---

# Google Chrome Browser Automation & Visual Debugging Guide

## When to Use This Skill
Trigger whenever capturing rendered screenshots of frontend projects (React, Next.js, HTML), scraping dynamic SPAs, debugging visual layouts, generating PDFs, or configuring browser automation in tests.

---

## 1. Global CLI Utility (`browser.mjs`)

Execute the global Chrome headless utility from any directory across any workspace:

### A. Capture Viewport Screenshot
```bash
node C:/Users/bel/.gemini/config/scripts/browser.mjs screenshot https://example.com ./screenshot.png 1280 800
```

### B. Render & Inspect Complete Dynamic DOM
```bash
node C:/Users/bel/.gemini/config/scripts/browser.mjs dump http://localhost:3000
```

### C. Verify Page Status & Title
```bash
node C:/Users/bel/.gemini/config/scripts/browser.mjs check http://localhost:3000
```

### D. Export Page to PDF
```bash
node C:/Users/bel/.gemini/config/scripts/browser.mjs pdf https://example.com ./report.pdf
```

---

## 2. Programmatic Integration in Test Suites

### Playwright (Zero Chromium Download)
Configure Playwright tests to reuse the installed Google Chrome engine using `channel: 'chrome'`:

```ts
import { chromium, test, expect } from '@playwright/test';

test('homepage renders correctly', async () => {
  const browser = await chromium.launch({
    channel: 'chrome',
    headless: true
  });
  const page = await browser.newPage();
  await page.goto('http://localhost:3000');
  await expect(page).toHaveTitle(/My App/);
  await browser.close();
});
```

### Puppeteer / Puppeteer-Core (Direct Chrome Binary)
Configure Puppeteer scripts and MCP servers to point directly to Google Chrome:

```ts
import puppeteer from 'puppeteer-core';

const browser = await puppeteer.launch({
  executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  headless: 'new',
  args: ['--hide-scrollbars', '--disable-gpu']
});
const page = await browser.newPage();
await page.goto('http://localhost:3000');
await page.screenshot({ path: 'preview.png' });
await browser.close();
```

---

## 3. Advantages of Using Google Chrome
- **Zero Binary Downloads**: Reuses pre-installed Google Chrome at `C:\Program Files\Google\Chrome\Application\chrome.exe`.
- **No Cache Locking**: Eliminates Windows `EPERM` file locks during npm/npx execution.
- **Isolated Profile Safety**: Uses independent `--user-data-dir` profiles in temp storage to avoid interfering with running user browser instances.
- **Full DevTools Protocol**: Complete support for Chrome DevTools Protocol (CDP), full-fidelity rendering, and modern headless flags (`--headless=new`).
