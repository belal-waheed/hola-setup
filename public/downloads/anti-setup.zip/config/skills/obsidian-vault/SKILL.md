---
name: obsidian-vault
description: Standards and architecture for Obsidian markdown vaults, Obsidian Bases (.base), and JSON Canvas (.canvas). Covers the 9-folder taxonomy, YAML frontmatter schemas, wikilinks, Dataview queries, database views, and coordinate layout algorithms for canvas diagrams. Use when creating or modifying notes, databases, templates, or visual canvas boards in an Obsidian vault.
---

# Obsidian Vault Architecture, Bases & Canvas Guide

Comprehensive guide for managing markdown notes, databases, and visual canvas graphs inside an Obsidian vault.

---

## 1. Vault Taxonomy & Routing Matrix

| Folder | Purpose | Standard Content / Files |
| :--- | :--- | :--- |
| **`inbox/`** | Fast capture & daily execution | `inbox/Today.md` (rolling execution note), `inbox/Inbox.md` |
| **`sprints/`** | Sprint planning & weekly cycles | `sprints/Week-YYYY-Wxx.md`, `_sprints.md` |
| **`projects/`** | Project workspaces | `projects/[name]/_[name].md` (hub note), tickets, architecture notes |
| **`areas/`** | Long-term knowledge bases | `areas/tech/backend/`, `areas/tech/frontend/`, `areas/career/` |
| **`resources/`** | Reference library & bookmarks | `resources/articles/`, `resources/bookmarks/` |
| **`archive/`** | Cold storage | `archive/completed-projects/`, `archive/backups/` |
| **`system/`** | Templates, scripts & assets | `system/templates/`, `system/scripts/`, `system/assets/` |

---

## 2. Markdown Note Schemas & Frontmatter

### A. Rolling Daily Note (`inbox/Today.md`)
```markdown
---
type: task-daily
date: 2026-09-04
day: Friday
week: "[[sprints/Week-2026-W36|Week-2026-W36]]"
tags:
  - daily
  - planning
---

# Today — 2026-09-04, Friday

## The Frog (Top 3 Priority Actions)
- [ ] Priority 1 #today
- [ ] Priority 2 #today
- [ ] Priority 3 #today

---

## Execution Checklist
- [ ] Secondary task #next

---

## Daily Scratchpad & Notes
*Technical decisions, snippets, endpoints, and commands run today.*
```

### B. Project Hub Note (`projects/[name]/_[name].md`)
```markdown
---
type: project-hub
status: active
priority: p1
tags:
  - project
---

# [Project Name] Hub

## Overview & Architecture
Summary and tech stack.

## Active Sprint Deliverables
- [ ] Deliverable 1
```

---

## 3. Obsidian Bases (`.base`) Integration

A `.base` file defines structured tabular and board views over markdown frontmatter properties:

```yaml
filters:
  and:
    - file.folder == "projects"
    - file.tags contains "#active"
views:
  - type: table
    name: "Active Projects"
    columns:
      - property: file.name
        label: "Project"
      - property: status
        label: "Status"
      - property: priority
        label: "Priority"
      - property: due_date
        label: "Due Date"
```
- Supported types: `text`, `number`, `date` (ISO `YYYY-MM-DD`), `multiselect`, `checkbox`.
- Always use relative vault paths in base filters.

---

## 4. Obsidian JSON Canvas (`.canvas`) Generation

A `.canvas` file is a JSON object with collision-free coordinates for visual node graphs:

```json
{
  "nodes": [
    {
      "id": "node_1",
      "type": "text",
      "text": "## API Gateway\n- Port: 8000",
      "x": 0,
      "y": 0,
      "width": 260,
      "height": 140,
      "color": "5"
    },
    {
      "id": "node_2",
      "type": "file",
      "file": "projects/auth/_auth.md",
      "x": 320,
      "y": 0,
      "width": 260,
      "height": 140,
      "color": "4"
    }
  ],
  "edges": [
    {
      "id": "edge_1",
      "fromNode": "node_1",
      "fromSide": "right",
      "toNode": "node_2",
      "toSide": "left",
      "label": "Routes to"
    }
  ]
}
```
- **Semantic Colors**: `1`: Red/Alert, `2`: Orange/Next, `3`: Yellow/Note, `4`: Green/Done, `5`: Blue/Component, `6`: Purple/System.

---

## 5. Verification & Linting

Validate files inside the vault:
```powershell
# Verify frontmatter parses cleanly
pwsh -NoProfile -Command "Get-Content 'inbox/Today.md' | Select-Object -First 10"

# Verify JSON Canvas syntax
node -e "JSON.parse(require('fs').readFileSync('architecture.canvas', 'utf8'))"
```
