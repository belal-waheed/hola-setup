---
name: skill-engineering
description: Design, author, audit, and optimize Antigravity skills. Enforces anti-slop guidelines, progressive disclosure, concise triggers, and verification standards across ~/.gemini/config/skills/ and workspace .agents/skills/. Use when creating new skills, auditing existing skills, or optimizing skill token footprints.
---

# Skill Engineering, Auditing & Quality Standard

Comprehensive runbook for authoring, auditing, and maintaining high-craft Antigravity skills.

---

## 1. Skill vs. Rule vs. Workflow Decision Gate

- **Global Rule (`GEMINI.md`):** Invariant constraints on how code, chat, or safety MUST always be handled across all projects.
- **Skill (`SKILL.md`):** Task-specific knowledge, multi-step procedures, or domain conventions loaded *only when triggered*.
- **Workflow:** Standalone execution scripts or orchestrations.
- *Default to Skill when in doubt*: It only enters context when relevant, preserving token budget.

---

## 2. Quality Rubric & Anti-Slop Standards (10/10 Target)

1. **Frontmatter Rigor (3.0 pts):**
   - `name`: Lowercase kebab-case, exactly matches folder name.
   - `description`: Third person, starts with action/trigger condition ("Use when...", "Conventions for..."), < 50 words, zero filler.
2. **Token Economy & Anti-Slop (2.0 pts):**
   - Zero tutorial introductions or basic conversational filler.
   - Imperative, operational instructions only.
   - Line count target: < 150 lines for `SKILL.md`. Split deep references into `references/<topic>.md`.
3. **Progressive Disclosure (2.0 pts):**
   - Main `SKILL.md` acts as the router/runbook.
   - Executable scripts belong in `scripts/`.
   - Boilerplate files belong in `resources/` or `references/`.
4. **Verification & Testing Protocol (1.5 pts):**
   - Every skill must have an explicit verification command (`npm test`, `pwsh`, `dotnet test`, dry run).
5. **Negative Constraints & Anti-Patterns (1.5 pts):**
   - Explicit "Pitfalls / What NOT to do" section.

---

## 3. Canonical SKILL.md Template

```markdown
---
name: <kebab-case-name>
description: <what it does + specific trigger conditions in < 50 words>
---

# <Skill Title>

<One-sentence overview of the operational standard.>

---

## 1. Execution Directives & Principles
- Rule 1
- Rule 2

---

## 2. Core Patterns & Code Examples
```language
// Canonical implementation snippet
```

---

## 3. Verification & Testing
1. Command to test/validate:
   ```bash
   <verification-command>
   ```

---

## 4. Common Pitfalls & Negative Constraints
- Never do X.
- Avoid Y.
```

---

## 4. Automated Audit Command

To audit skills across the environment:
```bash
node C:\Users\bel\.gemini\config\scripts\audit-skills.mjs
```
Ensure all YAML blocks parse and exit code is 0.
