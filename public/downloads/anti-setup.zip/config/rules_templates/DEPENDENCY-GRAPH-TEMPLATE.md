# [Project Name] Relational Dependency Graph & Architecture Map

> Living relational map of cross-service connections, internal module dependencies, and database schema foreign keys.
> Must be consulted before altering public interfaces or schemas, and updated upon structural modifications.

---

## 1. System Context & External Integrations
```mermaid
flowchart TD
    Client["Client (Browser / Mobile)"]
    API["API Gateway / Backend Service"]
    DB[(Primary Database)]
    Cache[(Redis Cache)]
    ExtService["External Third-Party Service"]

    Client -->|HTTPS / REST / WS| API
    API -->|Read / Write Pool| DB
    API -->|Key-Value / PubSub| Cache
    API -->|Outbound Webhooks / SDK| ExtService
```

| External Dependency | Purpose / Integration Point | Auth / Secrets Ref | Failure Strategy |
| :--- | :--- | :--- | :--- |
| `PostgreSQL` | Primary ACID relational datastore | `$env:DATABASE_URL` | Fail-fast with connection pool retry |
| `Redis` | Session cache & rate limiter | `$env:REDIS_URL` | Graceful degradation / cache bypass |
| `Resend` | Transactional email delivery | `$env:RESEND_API_KEY` | Dead-letter queue / retry policy |

---

## 2. Internal Module Dependency Hierarchy
Enforce strict topological acyclic ordering:
```mermaid
graph TD
    UI["Presentation / UI Layer"]
    App["Application / Orchestration Layer"]
    Domain["Domain Core (Entities & Invariants)"]
    Infra["Infrastructure (DB, Adapters, Network)"]

    UI --> App
    App --> Domain
    Infra --> Domain
    App -.->|Inversion of Control (Interfaces)| Infra
```

### Module Call Graph & Public Contracts
| Source Module | Dependent Module | Imported Interface / Method | Impact Risk |
| :--- | :--- | :--- | :--- |
| `presentation/api` | `application/services` | `EntityService.create(...)` | High - changes affect client contracts |
| `application/services` | `infrastructure/repo` | `IEntityRepository.getById(...)` | Medium - changes affect DB queries |
| `infrastructure/repo` | `domain/entities` | `Entity` model & invariants | Critical - changes affect core logic |

---

## 3. Database Schema Relational Graph (ERD)
```mermaid
erDiagram
    USERS ||--o{ ORDERS : places
    ORDERS ||--|{ ORDER_ITEMS : contains
    PRODUCTS ||--o{ ORDER_ITEMS : referenced_in

    USERS {
        uuid id PK
        string email UK
        timestamptz created_at
    }
    ORDERS {
        uuid id PK
        uuid user_id FK
        string status
        numeric total_amount
    }
    PRODUCTS {
        uuid id PK
        string sku UK
        int stock_quantity
    }
    ORDER_ITEMS {
        uuid id PK
        uuid order_id FK
        uuid product_id FK
        int quantity
        numeric unit_price
    }
```

### Foreign Key & Cascade Policies
| Parent Table | Child Table | Foreign Key Column | On Delete Action | On Update Action |
| :--- | :--- | :--- | :--- | :--- |
| `users` | `orders` | `orders.user_id` | `RESTRICT` | `CASCADE` |
| `orders` | `order_items` | `order_items.order_id` | `CASCADE` | `CASCADE` |
| `products` | `order_items` | `order_items.product_id` | `RESTRICT` | `CASCADE` |

---

## 4. Pre-Modification Impact Checklist
Before refactoring or removing any entity, function, or schema column:
- [ ] Language server reference check (`Find All References`) executed for the target symbol.
- [ ] Database migration rollback script prepared and tested.
- [ ] Downstream consumers identified and updated atomically in the same commit.
- [ ] Living documentation (`SPEC.md`, `RULES.md`, `DEPENDENCY_GRAPH.md`) updated.
