# [Project Name] Domain Specification & System Contracts

> Living specification defining domain boundaries, state machines, business invariants, and API contracts.
> Keep synchronized upon every feature addition or refactor.

---

## 1. Ubiquitous Domain Terminology
| Term | Exact Definition | Disallowed Synonyms | Scope / Context |
| :--- | :--- | :--- | :--- |
| `EntityName` | Core business entity representing... | Do not call `Obj` or `Model` | Domain layer |
| `StatusName` | Operational lifecycle stage... | Avoid ambiguous labels | State machine |

---

## 2. Invariants & Business Rules
Explicit guarantees that the system must uphold at all times:
1. **[Invariant 1]**: Every entity must possess a unique, immutable UUIDv7 / GUID upon creation.
2. **[Invariant 2]**: Status transitions must adhere strictly to the allowed lifecycle transitions.
3. **[Invariant 3]**: Financial / numerical amounts must use integer cents or fixed-point decimal types.

---

## 3. Explicit State Machines
Never use ambiguous boolean flags (e.g., `isLoading`, `isFailed`, `isDone`). Model all lifecycles as explicit discriminated unions:

```typescript
// TypeScript / Node.js
export type LifecycleState =
  | { status: 'draft'; createdAt: Date }
  | { status: 'pending_validation'; submittedAt: Date }
  | { status: 'active'; activatedAt: Date; version: number }
  | { status: 'suspended'; suspendedAt: Date; reason: string }
  | { status: 'archived'; archivedAt: Date };
```

```csharp
// C# / ASP.NET Core
public abstract record LifecycleState
{
    public record Draft(DateTime CreatedAt) : LifecycleState;
    public record PendingValidation(DateTime SubmittedAt) : LifecycleState;
    public record Active(DateTime ActivatedAt, int Version) : LifecycleState;
    public record Suspended(DateTime SuspendedAt, string Reason) : LifecycleState;
    public record Archived(DateTime ArchivedAt) : LifecycleState;
}
```

### State Transition Matrix
| Current State | Trigger / Event | Next State | Guard / Condition |
| :--- | :--- | :--- | :--- |
| `draft` | `SubmitForReview` | `pending_validation` | Must satisfy validation schema |
| `pending_validation` | `Approve` | `active` | Authorized admin role |
| `pending_validation` | `Reject` | `draft` | Rejection reason required |
| `active` | `Suspend` | `suspended` | Invariant breach detected |
| `suspended` | `Restore` | `active` | Remediation confirmed |
| `active` / `suspended` | `Archive` | `archived` | Zero pending transactions |

---

## 4. API & Integration Contracts

### Contract: `[POST /api/v1/entities]`
- **Purpose**: Creates a new domain entity.
- **Input Validation (Edge Schema)**:
```typescript
export const CreateEntitySchema = z.object({
  title: z.string().min(3).max(120),
  category: z.enum(['standard', 'priority']),
  payload: z.record(z.unknown())
});
```
- **Responses**:
  - `201 Created`: `{ success: true, data: EntityResponse }`
  - `400 Bad Request`: `{ success: false, error: ValidationError }`
  - `409 Conflict`: `{ success: false, error: DuplicateEntityError }`
- **Result Return Type (Service Layer)**:
```typescript
export type CreateEntityResult = Result<Entity, ValidationError | ConflictError>;
```

---

## 5. Persistence Schema Contracts
- **Primary Table**: `entities`
- **Primary Key**: `id UUID PRIMARY KEY DEFAULT gen_random_uuid()`
- **Foreign Keys**: `parent_id REFERENCES parents(id) ON DELETE RESTRICT`
- **Audit Columns**: `created_at TIMESTAMPTZ NOT NULL`, `updated_at TIMESTAMPTZ NOT NULL`, `version INT NOT NULL DEFAULT 1`

---

## 6. Adopted Component Libraries & Third-Party Foundations (Zero-Reinvention)
Explicit record of established packages adopted to prevent hand-rolling from zero:

| Domain Layer | Adopted Library / Primitive | Purpose | Customization Strategy |
| :--- | :--- | :--- | :--- |
| **Interactive UI** | [e.g. Radix UI / Shadcn UI / Ark UI] | Accessible dialogs, popovers, dropdowns | Customized via project Tailwind v4 tokens |
| **Data Tables** | [e.g. TanStack Table] | Headless sorting, pagination, filtering | Wrapped in accessible project UI table |
| **Icons & Visuals** | [e.g. Lucide Icons] | Clean SVG vector iconography | Zero emojis; strict SVG icon wrapper |
| **Validation** | [e.g. Zod / FluentValidation] | Edge schema parsing & fail-fast checks | Pipeline middleware validation |
| **State & Local DB** | [e.g. Dexie.js / SQLite OPFS] | Local-first offline mutation storage | IndexedDB wrapper with idempotency keys |
| **Command Bus** | [e.g. MediatR / Custom CQRS handler] | CQRS decoupling & pipeline behaviors | Feature slice request handlers |

*Invariant*: Coding any primitive listed above from scratch without team architectural sign-off is strictly prohibited.
