# [Project Name] Architectural Rules & Boundary Invariants

> Project-level architectural constraints governing layers, dependencies, error handling, and testing.
> Enforced across all agents and human contributors.

---

## 1. Architectural Style & Layering
- **Architecture Pattern**: [Layered Clean Architecture / Vertical Slice Architecture / Hexagonal]
- **Strict Boundary Flow**: `Presentation / Controllers` -> `Application / Service Layer` -> `Infrastructure / Repositories` -> `Domain Core`.
- **Dependency Rule**: Dependencies point inward only. Domain Core has ZERO external framework dependencies.

---

## 2. Boundary Invariants & Data Flow
1. **Edge Schema Validation**: Every external input (HTTP body, query param, webhook payload, IPC message) MUST be parsed and validated with schemas (Zod / Pydantic / FluentValidation) before touching service logic.
2. **Service Layer Result Return**: Business logic MUST return `Result<T, E>`. Never bubble up raw HTTP exceptions or throw domain exceptions for expected failure paths.
3. **Database Entity Encapsulation**: Database ORM entities (EF Core / Mongoose / Prisma) MUST NEVER leak into API responses or UI view models. Explicit mapper / DTO transformations required.
4. **Relational Impact Integrity**: Before modifying any public method, type signature, or database column, map and update all dependent modules atomically in the same commit.

---

## 3. Technology Stack & Zero-Reinvention Invariants
- **Zero-Reinvention Mandate (Never Build From Scratch):** Never build complex UI components (dialogs, dropdowns, data tables, drawers, popovers, tooltips, select menus) from zero. Always adopt battle-tested accessible component libraries (Radix UI, Shadcn UI / Base UI, Ark UI, TanStack Table) and customize them via Tailwind v4 `@theme` design tokens. Never hand-roll state machines, ORM wrappers, or caching layers when standard libraries exist.
- **Runtime & Language**: [e.g. Node.js 22 LTS / .NET 9 / Python 3.12]
- **Web Framework**: [e.g. Next.js 15 App Router / ASP.NET Core 9 / Express]
- **Styling & UI**: Tailwind CSS v4 (`@theme`), WCAG AA contrast (4.5:1), 8px spatial grid, zero inline style hacks, zero emojis.
- **Client/Server Boundary**: React Server Components by default; `'use client'` strictly restricted to interactive leaves.
- **Query Optimization**: Read operations must disable tracking (e.g. `.AsNoTracking()`), enforce pagination limits, and handle cancellations (`CancellationToken` / `AbortSignal`).

---

## 4. Testing & Verification Standards
- **Testing Pattern**: Arrange-Act-Assert (AAA) pattern.
- **Strict Prohibition**: NEVER mock the System Under Test (SUT). Only mock external boundary I/O dependencies (third-party payment APIs, SMS gateways).
- **Mandatory Coverage**:
  - All domain invariants and state machine transitions covered by automated unit tests.
  - Critical integration paths validated against test database containers or in-memory repositories.
- **Regression Guard**: Any reported bug must be reproduced with a failing unit test before applying the fix.

---

## 5. Living Documentation & Sync Protocol
- Update `SPEC.md` immediately upon altering any domain rule, state transition, or API contract.
- Update `DEPENDENCY_GRAPH.md` upon modifying package imports, module boundaries, or database relationships.
- Co-locate change summaries into the relevant vault log note (`projects/<project>/_log.md`).
