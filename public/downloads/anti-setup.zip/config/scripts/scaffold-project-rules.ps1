﻿<#
.SYNOPSIS
    scaffold-project-rules.ps1 - Automated Project Architectural Governance Scaffolder

.DESCRIPTION
    Scaffolds project-scoped Antigravity and AI agent governance into any target project:
    - .agents/rules/<stack>.md (Technology stack standards)
    - GEMINI.md (Project architectural boundaries and invariant rules)
    - CONTEXT.md (Ubiquitous language domain glossary)
    - DEPENDENCY-GRAPH.md (Relational dependency & architecture map)
    - docs/adr/0001-record-architecture-decisions.md (Foundational ADR)

.PARAMETER Project
    The name of the project inside D:\dev\projects or an absolute directory path.

.PARAMETER Stack
    The tech stack profile: nextjs, aspnet, node-ts, ahk-v2. Default: nextjs.

.PARAMETER DryRun
    Simulates file generation without writing to disk.

.PARAMETER Force
    Overwrites existing files if they already exist.
#>

[CmdletBinding()]
param (
    [Parameter(Position = 0, Mandatory = $true)]
    [string]$Project,

    [Parameter(Position = 1)]
    [ValidateSet("nextjs", "aspnet", "node-ts", "ahk-v2")]
    [string]$Stack = "nextjs",

    [switch]$DryRun,
    [switch]$Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$TemplatesDir = "C:\Users\bel\.gemini\config\rules_templates"
if (-not (Test-Path -LiteralPath $TemplatesDir)) {
    throw "Templates directory not found: $TemplatesDir"
}

# Resolve project path
$ProjectPath = if ([System.IO.Path]::IsPathRooted($Project)) {
    $Project
} else {
    Join-Path "D:\dev\projects" $Project
}

if (-not (Test-Path -LiteralPath $ProjectPath)) {
    throw "Target project directory does not exist: $ProjectPath"
}

$ProjectName = Split-Path -Leaf $ProjectPath
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " Antigravity Project Architectural Governance Scaffolder" -ForegroundColor Cyan
Write-Host " Target: $ProjectPath" -ForegroundColor Gray
Write-Host " Stack:  $Stack" -ForegroundColor Gray
Write-Host " Mode:   $(if ($DryRun) { 'DryRun (Simulation)' } else { 'Execute' })" -ForegroundColor Gray
Write-Host "============================================================" -ForegroundColor Cyan

function Write-ScaffoldFile {
    param (
        [string]$RelativePath,
        [string]$Content
    )

    $fullPath = Join-Path $ProjectPath $RelativePath
    $parentDir = Split-Path -Parent $fullPath

    if (Test-Path -LiteralPath $fullPath) {
        if (-not $Force) {
            Write-Host "  [SKIP] Exists: $RelativePath (use -Force to overwrite)" -ForegroundColor DarkGray
            return
        }
        Write-Host "  [OVERWRITE] $RelativePath" -ForegroundColor Yellow
    } else {
        Write-Host "  [CREATE] $RelativePath" -ForegroundColor Green
    }

    if (-not $DryRun) {
        if (-not (Test-Path -LiteralPath $parentDir)) {
            New-Item -ItemType Directory -Path $parentDir -Force | Out-Null
        }
        [System.IO.File]::WriteAllText($fullPath, $Content, [System.Text.UTF8Encoding]::new($false))
    }
}

# 1. Stack Rules (.agents/rules/<stack>.md)
$stackTemplatePath = Join-Path $TemplatesDir "$Stack.md"
if (Test-Path -LiteralPath $stackTemplatePath) {
    $stackContent = Get-Content -LiteralPath $stackTemplatePath -Raw -Encoding utf8
    Write-ScaffoldFile -RelativePath ".agents\rules\$Stack.md" -Content $stackContent
}

# 2. Project GEMINI.md
$geminiContent = @"
# $ProjectName — Architectural Rules & Boundary Invariants

**Target Audience:** AI Coding Assistants (Antigravity) & Human Contributors  
**Project Workspace:** `$ProjectPath`  
**Stack Profile:** $Stack  
**Status:** Canonical & Mandatory Workspace Rule (Auto-loaded in session)

---

## 1. Architectural Style & Layering
- **Strict Boundary Flow:** Presentation / UI -> Application / Domain Services -> Infrastructure / Repositories.
- **Dependency Rule:** Dependencies point inward only. Domain core has zero external framework dependencies.
- **Result Pattern:** Services encapsulate domain logic and return ``Result<T, E>``. Never throw unhandled exceptions for expected domain failures.
- **Explicit State Machines:** Reject ambiguous boolean flags (``isLoading``, ``isError``). Enforce discriminated union states.

---

## 2. Relational Impact & Pre-Modification Law
- Map all callers via AST search or grep before altering public interfaces, schemas, or route handlers.
- Breaking signature changes must be propagated atomically across all downstream callers within the same changeset.

---

## 3. Technology Standards
- Refer to [`.agents/rules/$Stack.md`](file:///.agents/rules/$Stack.md) for stack-specific coding standards.
- Refer to [`CONTEXT.md`](file:///CONTEXT.md) for ubiquitous domain language and terminology definitions.
- Refer to [`DEPENDENCY-GRAPH.md`](file:///DEPENDENCY-GRAPH.md) for module and database architecture maps.
"@

Write-ScaffoldFile -RelativePath "GEMINI.md" -Content $geminiContent

# 3. Ubiquitous Language Glossary (CONTEXT.md)
$contextContent = @"
# $ProjectName — Ubiquitous Domain Terminology & Context Glossary

> Living dictionary defining domain entities, system states, and business invariants for $ProjectName.
> Keep synchronized whenever introducing or altering domain concepts.

---

## 1. Ubiquitous Domain Terminology

| Term | Canonical Definition | Disallowed / Deprecated Synonyms | Scope / Boundary |
| :--- | :--- | :--- | :--- |
| `EntityName` | Core domain entity representing... | Do not call `Obj` or `Model` | Domain Core |
| `StatusState` | Operational lifecycle state of... | Avoid loose boolean flags | State Machine |

---

## 2. Domain Invariants & Business Rules
- **INV-01:** Business invariant rule description.
- **INV-02:** State transition validation constraint.
"@

Write-ScaffoldFile -RelativePath "CONTEXT.md" -Content $contextContent

# 4. Relational Dependency Graph (DEPENDENCY-GRAPH.md)
$depTemplatePath = Join-Path $TemplatesDir "DEPENDENCY-GRAPH-TEMPLATE.md"
if (Test-Path -LiteralPath $depTemplatePath) {
    $depContent = Get-Content -LiteralPath $depTemplatePath -Raw -Encoding utf8
    $depContent = $depContent -replace "\[Project Name\]", $ProjectName
    Write-ScaffoldFile -RelativePath "DEPENDENCY-GRAPH.md" -Content $depContent
}

# 5. Foundational ADR (docs/adr/0001-record-architecture-decisions.md)
$dateStr = (Get-Date).ToString("yyyy-MM-dd")
$adrContent = @"
# ADR-0001: Record Architecture Decisions

**Status:** Accepted  
**Date:** $dateStr  
**Deciders:** Lead Software Engineer / Antigravity Agent  

---

## 1. Context & Problem Statement
We need to record architectural and design decisions made on $ProjectName so that current and future contributors (human and AI) understand why the system is built the way it is.

## 2. Decision Outcome
We will use Architecture Decision Records (ADRs) structured in `docs/adr/` using sequential numbers (`NNNN-title.md`).
- Every ADR documents the problem context, decision drivers, considered options, chosen outcome, and consequences.
- Once accepted, ADRs are immutable records of historical decision context. Superseded decisions are marked with a link to the new ADR.
"@

Write-ScaffoldFile -RelativePath "docs\adr\0001-record-architecture-decisions.md" -Content $adrContent

Write-Host "`nScaffolding complete for $ProjectName ($Stack).`n" -ForegroundColor Green
