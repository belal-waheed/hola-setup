# Antigravity Global Engineering Standards & Governance

These rules apply universally across all workspaces, sessions, and executions. Stack-specific standards and workflow runbooks are progressively disclosed via specialized plugin skills.

---

## 1. Safety & Guardrails
- **Destructive Commands Prohibited:** Never execute destructive file or directory deletions (`rm -rf /`, `rmdir /s /q`, `del /s /q` on root/system/parent dirs) or destructive Git commands (`git reset --hard`, `git push --force`, `git clean -fd`) without explicit user instruction.
- **Package Isolation:** Never install packages globally (`npm install -g`, `pip install --user` outside venv, `winget`, `choco`). Install dependencies only within local project scope (`npm install --save`, active virtual environments `venv`).
- **Secrets & System Integrity:** Never expose, hardcode, or overwrite `.env` files, API keys, or system directories (`C:\Windows`, `C:\Program Files`, registry).

---

## 2. UI/UX Craftsmanship & Component Library Standards
- **Zero Emojis in Code & Chat:** Never use emojis in UI components, terminal output, or markdown reports unless explicitly requested. Use clean SVG vector icons (Lucide, Heroicons, Radix Icons).
- **Never Build Complex UI From Scratch (Component Library Mandate):** Never code complex interactive UI widgets (dialogs, dropdowns, popovers, custom selects, comboboxes, data tables, tooltips, drawers, navigation menus) from zero. Always search for and adopt battle-tested, accessible headless or styled component libraries (Radix UI, Shadcn UI / Base UI, Ark UI, Headless UI, TanStack Table). Import the proven primitives and customize them specifically to the project using Tailwind v4 CSS-first design tokens (`@theme`).
- **Design Integrity:** Reject generic dark-slate/neon-purple AI templates. Use WCAG AA contrast (4.5:1), 8px spatial grid, and CSS-first Tailwind v4 tokens (`@theme`).

---

## 3. Relational Dependency & Impact Analysis (The Integrity Law)
- **Pre-Modification Impact Mapping:** Before modifying or deleting any type, interface, function signature, API route, or database column/schema, the agent MUST map all dependents and callers (via AST search, language server, or grep across the codebase).
- **Atomic Propagation:** Any breaking contract or signature change must be propagated atomically across all downstream callers within the same changeset. Speculative or partial modifications that leave sibling files or consumers broken are strictly forbidden.

---

## 4. Explicit State Machines & Anti-AI Slop Invariants
- **No Boolean Flag Soup:** Never use ambiguous boolean combinations (e.g., `isLoading`, `isError`, `isSuccess`, `data`). Enforce explicit discriminated union state machines:
  `type AsyncState<T, E> = { status: 'idle' } | { status: 'pending' } | { status: 'success'; data: T } | { status: 'error'; error: E }`.
- **Mandatory Result Pattern:** Services encapsulate business logic and return `Result<T, E>` (or equivalent `OneOf` / custom Result pattern). Never throw unhandled exceptions for predictable domain failure paths; handle errors at system boundaries.
- **Zero Mocking of System Under Test:** Unit test domain logic and API boundaries adhering strictly to Arrange-Act-Assert (AAA). Test real domain logic without mocking the unit under test.
- **Fail-Fast Invariants:** Validate inputs at system boundaries using strict schema validation (Zod in TypeScript, Pydantic in Python, FluentValidation in C#).

---

## 5. Adversarial Engineering & The Zero-Reinvention Mandate
- **Zero Sycophancy:** Never blindly agree with or rubber-stamp suboptimal, flawed, or fragile technical proposals. If a proposed approach has hidden risks, architectural flaws, security gaps, performance bottlenecks, or scalability limits, state the concrete trade-offs directly from first principles.
- **Constructive Alternatives:** Every technical critique MUST be immediately paired with a superior, concrete, and well-reasoned alternative pattern.
- **The Zero-Reinvention Law (Never Build From Scratch):** Never author custom mechanisms, hand-rolled state machines, DIY pub/sub, ad-hoc caching, homebrew ORM wrappers, or reinvent known software wheels when an established industry library or standard pattern (GoF, Enterprise Application Patterns, Cloud Patterns) exists. Search first across npm/NuGet/crates, adopt the proven library, and customize it to project constraints.
- **Skill & Customization Sourcing Mandate:** Never hand-roll custom skills or configurations from scratch. Always search for and vet official vendor standards (Google, Microsoft, Tauri, Playwright) and proven community engineering repositories. Import the vetted base skill or configuration, then configure and specialize it to our Antigravity setup.
- **Calibrated Rigor:** Apply rigorous pushback to high- and medium-impact technical decisions (architecture, schema design, security, performance, correctness) while executing trivial preferences smoothly without friction.

---

## 6. Execution Control & Planning Protocol
- **Interactive Mode (Default):** When the user requests a plan, investigation, or architectural outline, draft the plan and STOP. Never auto-execute, modify files, or run modifying commands without explicit user confirmation.
- **Autonomous Mode (`/goal` Only):** Only when the user explicitly triggers `/goal` or requests unattended execution may the agent proceed through execution steps autonomously without intermediate confirmation.

---

## 7. First-Principles Thinking & Token Efficiency
- **First-Principles Decomposition:** Break complex problems down to fundamental truths and verified root causes before designing or writing code. Eliminate edge cases at the system boundary rather than patching symptoms.
- **Dense Technical Communication:** Deliver maximum information density per token. Write concise, direct, bulleted explanations without conversational preamble, repetitive apologies, or fluff.
- **Defensive Design Integrity:** Design interfaces with explicit state machines, fail-fast invariants, and unambiguous boundaries to prevent drift and cascading failures.

---

## 8. MCP & API Authentication Standards
- **Environment Variables Over Configs:** Never hardcode plaintext tokens or API keys in `mcp_config.json` or scripts. Always rely on Windows User Environment Variables (e.g. `$env:GITHUB_PERSONAL_ACCESS_TOKEN`, `$env:RESEND_API_KEY`, `$env:VERCEL_TOKEN`). MCP servers will automatically inherit these credentials.
- **MCP Limitations Fallback:** When an MCP server lacks a specific endpoint, gracefully fall back to calling the provider's REST API directly using PowerShell (`Invoke-RestMethod`), authenticated via the respective environment variable token.

---

## 9. SQL Engineering Standards & Seed Data Whitelist
- **Casing & Grammar (Style 3):**
  - **Single Keywords:** PascalCase (`Select`, `From`, `Where`, `Join`, `On`, `As`, `Group By`, `Order By`, `Having`, `Create`, `Alter`, `Drop`, `Table`, `View`, `Index`, `Trigger`, `Procedure`, `Begin`, `End`, `Declare`, `Set`, `Exec`, `Print`, `Values`, `Top`, `Distinct`, `Between`, `Like`, `In`, `Is`, `Null`, `Not`, `And`, `Or`, `Exists`, `Case`, `When`, `Then`, `Else`, `Returns`, `Return`, `Rollback`, `Commit`, `Transaction`, `After`, `Instead Of`, `Throw`).
  - **Compound Keywords:** Compound PascalCase (`InTo`, `UpDate`).
  - **Operators & Clean Syntax:**
    - Always use `Join` instead of `INNER JOIN`.
    - Always use `!=` instead of `<>`.
    - Use modern null-safe comparison `col1 Is Distinct From col2` (SQL Server 2022+) instead of hacky magic numbers like `ISNULL(col1, -1) != ISNULL(col2, -1)`.
  - **Data Types:** Standard concise types (`int`, `varchar(...)`, `nvarchar(...)`, `date`, `datetime`, `decimal(...)`, `money`).
- **Seed & Sample Data Whitelist:**
  When generating mock rows, test insertions, or seeding demonstration tables, ONLY draw values from this strict whitelist:
  - **Approved Names (TitleCase):** `Belal`, `Waheed`, `Hola`, `Bel`, `Ali`, `Romesa`, `Bola`, `Bale`, `Marem`, `3essam`, `Feras`, `Ramadan`, `3mr`, `Omar`.
  - **Approved Birth Years (ISO Format 'YYYY-MM-DD'):** `2004`, `2005`, `2000`, `1965` (e.g., `'2004-05-15'`, `'2005-10-20'`, `'2000-01-01'`, `'1965-03-12'`).
  - **Relational Key & Identity Invariant (Anti-Assumption Law):**
    - Never assume database primary keys start at `1` or follow standard increment sequences.
    - Never hardcode static project-specific table IDs into global configuration.
    - Always inspect the target database schema, verify actual primary key column names (e.g. `Number`, `Code` vs `Id`), and map real ID ranges before authoring queries, test scripts, or migrations.
    - Domain entity ranges, catalog IDs, and table structures belong exclusively in project-level rules or directory documentation.

---

## 10. Workstation Tri-Drive Topology & Dev Drive (`V:\`)
- **`V:\` (Dev Drive / ReFS):** Sole location for all active software engineering (`V:\projects\`, `V:\clients\`, `V:\labs\`, `V:\tools\`, `V:\packages\`). All active repos and package stores (`pnpm`, `cargo`, `nuget`, `npm`, `pip`, `deno`) reside exclusively on `V:`.
- **`D:\` (NTFS Storage):** Capacity anchor for developer knowledge, courses (`D:\dev\courses\`), academics (`D:\dev\su\`), career records (`D:\dev\career\`), and cold archived repos (`D:\dev\archive\`). Zero active repos on `D:`.
- **`C:\` (NTFS Host):** Reserved strictly for OS, user AppData, `.ssh`, and agent runtimes. Never initialize repositories or install unmanaged packages on `C:`.
- **Tool Resolution:** Developer scripts resolve via `V:\tools\` or the `D:\scripts` junction.


